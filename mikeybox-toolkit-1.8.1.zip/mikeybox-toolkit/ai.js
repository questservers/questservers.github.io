/* Mikeybox Toolkit — in-page AI Studio.
   Talks to background.js for every NVIDIA call so the API key never reaches the page. */
(function () {
  'use strict';
  if (window.__mbxAIStudioLoaded) return;
  window.__mbxAIStudioLoaded = true;

  const CORE = window.MBXAICore;
  const MBX = window.MBX;
  if (!CORE) return;

  const DEFAULT_SETTINGS = (MBX && MBX.DEFAULT_SETTINGS) || {};
  const ART_KEY = 'mbxItemArt';
  const MAX_ART = 36;

  const state = {
    enabled: true,
    settings: Object.assign({}, DEFAULT_SETTINGS),
    aiSettings: Object.assign({}, CORE.DEFAULT_AI_SETTINGS),
    keyConfigured: false,
    catalog: [],
    categoryCounts: {},
    banned: new Set(),
    blacklist: new Set(),
    security: null,
    policy: null,
    site: null,
    versions: null,
    art: {},
    lastBuild: null,
    lastImage: '',
    uploadImage: '',
    dataAt: 0,
    busy: false,
    view: 'build',
    panel: null,
    button: null,
    dataPromise: null,
    profile: null,
  };

  let styleEl = null;
  let scanTimer = 0;
  let settingsBusy = false;

  const $ = (sel, root) => (root || document).querySelector(sel);
  const $$ = (sel, root) => Array.from((root || document).querySelectorAll(sel));

  /* ------------------------------------------------------------------ */
  /* Storage helpers                                                     */
  /* ------------------------------------------------------------------ */

  function syncGet(keys) {
    return new Promise((resolve) => {
      try {
        chrome.storage.sync.get(keys, (res) => resolve(res || {}));
      } catch (err) {
        resolve({});
      }
    });
  }

  function localGet(keys) {
    return new Promise((resolve) => {
      try {
        chrome.storage.local.get(keys, (res) => resolve(res || {}));
      } catch (err) {
        resolve({});
      }
    });
  }

  function localSet(object) {
    return new Promise((resolve) => {
      try {
        chrome.storage.local.set(object, () => resolve(true));
      } catch (err) {
        resolve(false);
      }
    });
  }

  function send(type, extra, timeoutMs) {
    return new Promise((resolve) => {
      let settled = false;
      const timer = setTimeout(() => {
        if (settled) return;
        settled = true;
        resolve({ ok: false, error: 'The AI worker did not answer in time.' });
      }, timeoutMs || 200000);
      try {
        chrome.runtime.sendMessage(Object.assign({ type: type }, extra || {}), (response) => {
          if (settled) return;
          settled = true;
          clearTimeout(timer);
          const err = chrome.runtime && chrome.runtime.lastError;
          if (err) resolve({ ok: false, error: err.message });
          else resolve(response || { ok: false, error: 'The AI worker returned no response.' });
        });
      } catch (err) {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        resolve({ ok: false, error: 'The AI worker is unavailable. Reload the extension.' });
      }
    });
  }

  function updateSetting(key, value) {
    state.settings[key] = value;
    try {
      chrome.storage.sync.get('settings', (res) => {
        const merged = Object.assign({}, DEFAULT_SETTINGS, (res && res.settings) || {}, { [key]: value });
        chrome.storage.sync.set({ settings: merged });
      });
    } catch (err) {
      /* ignore */
    }
  }

  /* ------------------------------------------------------------------ */
  /* Boot                                                                */
  /* ------------------------------------------------------------------ */

  function boot() {
    createStyle();
    loadLocalState();
    listen();
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', onReady, { once: true });
    } else {
      onReady();
    }
  }

  function onReady() {
    moveStyle();
    ensureButton();
    applyCatalogDecorations();
  }

  async function loadLocalState() {
    const [sync, local] = await Promise.all([
      syncGet(['settings']),
      localGet(['mbxAiSettings', ART_KEY, 'mbxAiLastBuild']),
    ]);
    state.settings = Object.assign({}, DEFAULT_SETTINGS, (sync && sync.settings) || {});
    state.enabled = state.settings.enabled !== false;
    state.aiSettings = Object.assign({}, CORE.DEFAULT_AI_SETTINGS, local.mbxAiSettings || {});
    state.art = local[ART_KEY] && typeof local[ART_KEY] === 'object' ? local[ART_KEY] : {};
    state.lastBuild = local.mbxAiLastBuild && local.mbxAiLastBuild.root ? local.mbxAiLastBuild : null;
    refreshStatus();
    applyEnabled();
    if (state.enabled && (state.settings.markBanned || state.settings.hideBanned)) {
      loadSiteData(false);
    }
    if (state.panel) {
      syncControls();
      renderLastBuild();
      renderGallery();
    }
  }

  async function refreshStatus() {
    const response = await send('mbx-ai-status', {}, 8000);
    state.keyConfigured = Boolean(response && response.ok && response.keyConfigured);
    if (response && response.ok && response.settings) {
      state.aiSettings = Object.assign({}, state.aiSettings, response.settings);
    }
    syncHeader();
    renderSettings();
  }

  /* The provider follows the saved key (AIza… = Gemini, nvapi-… = NVIDIA). */
  function providerName() {
    return state.aiSettings.provider === 'gemini' ? 'Gemini' : 'NVIDIA';
  }

  function syncHeader() {
    if (!state.panel) return;
    const sub = $('#mbx-ai-sub', state.panel);
    const configured = state.aiSettings.chatModel || CORE.AUTO_MODEL;
    const model = configured === CORE.AUTO_MODEL ? 'auto · best model' : configured;
    if (sub) sub.textContent = providerName() + ' · ' + model;
    const warn = $('#mbx-ai-keywarn', state.panel);
    if (warn) warn.hidden = state.keyConfigured;
    const hint = $('#mbx-ai-modelhint', state.panel);
    if (hint) hint.textContent = state.keyConfigured ? model : 'Add a key in settings';
    const scanInfo = $('#mbx-ai-scaninfo', state.panel);
    if (scanInfo) scanInfo.textContent = state.aiSettings.lastScanAt ? 'Scanned ' + new Date(state.aiSettings.lastScanAt).toLocaleString() : 'No scan yet';
  }

  function applyEnabled() {
    const on = state.enabled;
    if (state.button) state.button.style.display = on ? '' : 'none';
    if (!on && state.panel) closePanel();
    if (state.panel) state.panel.style.display = on ? '' : 'none';
    if (!on) clearDecorations();
  }

  function clearDecorations() {
    if (document.documentElement) document.documentElement.classList.remove('mbx-hide-banned');
    $$('.mbx-ai-art, .mbx-ai-flag, .mbx-ai-banned, .mbx-ai-pill').forEach((node) => node.remove());
    $$('.mbx-banned').forEach((node) => node.classList.remove('mbx-banned'));
  }

  function listen() {
    try {
      chrome.storage.onChanged.addListener((changes, area) => {
        if (area === 'sync' && changes.settings) {
          state.settings = Object.assign({}, DEFAULT_SETTINGS, changes.settings.newValue || {});
          state.enabled = state.settings.enabled !== false;
          applyEnabled();
          if (state.enabled) ensureButton();
          if (state.enabled && (state.settings.markBanned || state.settings.hideBanned) && !state.catalog.length) {
            loadSiteData(false);
          }
          applyCatalogDecorations();
          syncControls();
          if (state.panel && state.profile) {
            const wrap = $('#mbx-ai-profile', state.panel);
            if (wrap) drawProfile(wrap);
          }
        }
        if (area === 'local' && changes[ART_KEY]) {
          state.art = changes[ART_KEY].newValue || {};
          applyCatalogDecorations();
          renderGallery();
        }
        if (area === 'local' && changes.mbxAiSettings) {
          state.aiSettings = Object.assign({}, CORE.DEFAULT_AI_SETTINGS, changes.mbxAiSettings.newValue || {});
          syncHeader();
          renderSettings();
        }
        if (area === 'local' && changes.mbxAiKey) refreshStatus();
      });
    } catch (err) {
      /* ignore */
    }

    try {
      chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
        if (message && message.type === 'mbx-open-studio') {
          openPanel();
          if (sendResponse) sendResponse({ ok: true });
        }
        return false;
      });
    } catch (err) {
      /* ignore */
    }

    window.addEventListener('keydown', (event) => {
      if (!state.enabled) return;
      if (event.altKey && event.shiftKey && (event.key === 'a' || event.key === 'A')) {
        event.preventDefault();
        event.stopPropagation();
        togglePanel();
      }
    }, true);

    let pending = 0;
    const observe = () => {
      if (!document.body) return;
      const observer = new MutationObserver(() => {
        if (pending) return;
        pending = window.setTimeout(() => {
          pending = 0;
          applyCatalogDecorations();
          ensureButton();
        }, 300);
      });
      observer.observe(document.body, { childList: true, subtree: true });
    };
    if (document.body) observe();
    else document.addEventListener('DOMContentLoaded', observe, { once: true });
  }

  /* ------------------------------------------------------------------ */
  /* Styles                                                              */
  /* ------------------------------------------------------------------ */

  function createStyle() {
    if (styleEl) return;
    styleEl = document.createElement('style');
    styleEl.id = 'mbx-ai-style';
    styleEl.textContent = `
#mbx-ai-button {
  position: fixed; right: 68px; bottom: 44px; z-index: 2147483000;
  width: 46px; height: 46px; padding: 0; border-radius: 50%;
  border: 1px solid color-mix(in srgb, var(--accent, #6fc2ff) 55%, var(--line, #333842)) !important;
  background: linear-gradient(140deg, color-mix(in srgb, var(--accent, #6fc2ff) 85%, #ffffff), color-mix(in srgb, var(--accent, #6fc2ff) 55%, var(--panel2, #202329))) !important;
  color: color-mix(in srgb, var(--accent, #6fc2ff) 15%, #05070a) !important;
  font: 800 13px/1 "Segoe UI", Arial, sans-serif !important;
  letter-spacing: .04em; cursor: pointer;
  box-shadow: 0 10px 26px rgba(0,0,0,.4);
  display: grid; place-items: center;
}
#mbx-ai-button:hover { filter: brightness(1.08); transform: translateY(-1px); }
#mbx-ai-button span { pointer-events: none; }

#mbx-ai-panel {
  position: fixed; right: 14px; bottom: 100px; z-index: 2147483002;
  width: min(392px, calc(100vw - 28px)); max-height: min(82vh, 760px);
  display: none; flex-direction: column; overflow: hidden;
  background: var(--panel, #181a1f); color: var(--text, #eceff3);
  border: 1px solid var(--line, #333842); border-radius: 12px;
  box-shadow: 0 22px 54px rgba(0,0,0,.55);
  font: 12px/1.45 "Segoe UI", Arial, sans-serif;
}
#mbx-ai-panel.mbx-open { display: flex; }
#mbx-ai-panel * { box-sizing: border-box; }
#mbx-ai-panel .mbx-ai-gate {
  position: absolute; inset: 0; z-index: 6;
  display: flex; flex-direction: column; justify-content: center; gap: 10px;
  padding: 22px 18px; text-align: center;
  background: color-mix(in srgb, var(--panel, #181a1f) 97%, #000);
  border-radius: inherit;
}
#mbx-ai-panel .mbx-ai-gate[hidden] { display: none; }
#mbx-ai-panel .mbx-ai-gate h2 { margin: 0; font-size: 11px; letter-spacing: .1em; text-transform: uppercase; color: var(--muted, #a5acb8); }
#mbx-ai-panel .mbx-ai-gate p { margin: 0; font-size: 12.5px; line-height: 1.5; }
#mbx-ai-panel .mbx-ai-gate strong { color: #ffb4b4; }
#mbx-ai-panel .mbx-ai-gate .mbx-ai-gate-note { color: var(--muted, #a5acb8); font-size: 10.5px; }
#mbx-ai-panel .mbx-ai-gate-actions { display: flex; gap: 8px; justify-content: center; margin-top: 8px; }
#mbx-ai-panel .mbx-ai-gate-actions button { min-height: 30px; padding: 6px 18px; }
#mbx-ai-panel .mbx-ai-head {
  display: flex; align-items: center; gap: 8px; justify-content: space-between;
  padding: 10px 12px; border-bottom: 1px solid var(--line, #333842);
  background: color-mix(in srgb, var(--panel, #181a1f) 80%, var(--accent, #6fc2ff) 6%);
}
#mbx-ai-panel .mbx-ai-head strong { display: block; font-size: 13px; }
#mbx-ai-panel .mbx-ai-head small { display: block; color: var(--muted, #a5acb8); font-size: 10px; }
#mbx-ai-panel .mbx-ai-x {
  width: 26px; height: 26px; min-height: 0; padding: 0; border-radius: 7px;
  background: transparent !important; border: 1px solid transparent !important;
  color: var(--muted, #a5acb8) !important; font-size: 16px; line-height: 1;
}
#mbx-ai-panel .mbx-ai-x:hover { background: var(--panel2, #202329) !important; color: var(--text, #eceff3) !important; }
#mbx-ai-panel .mbx-ai-tabs { display: grid; grid-template-columns: repeat(3, 1fr); border-bottom: 1px solid var(--line, #333842); }
#mbx-ai-panel .mbx-ai-tab {
  min-height: 32px; padding: 6px 4px; border: 0 !important; border-bottom: 2px solid transparent !important;
  border-radius: 0 !important; background: transparent !important; color: var(--muted, #a5acb8) !important;
  font-size: 11.5px !important; font-weight: 600 !important;
}
#mbx-ai-panel .mbx-ai-tab.is-active { color: var(--text, #eceff3) !important; border-bottom-color: var(--accent, #6fc2ff) !important; }
#mbx-ai-panel .mbx-ai-body { padding: 11px 12px 13px; overflow: auto; }
#mbx-ai-panel .mbx-ai-view[hidden] { display: none; }
#mbx-ai-panel h3 { margin: 12px 0 6px; font-size: 11px; text-transform: uppercase; letter-spacing: .07em; color: var(--muted, #a5acb8); }
#mbx-ai-panel .mbx-ai-label { display: block; margin: 0 0 4px; color: var(--muted, #a5acb8); font-size: 10.5px; }
#mbx-ai-panel textarea, #mbx-ai-panel input[type="text"], #mbx-ai-panel input[type="password"], #mbx-ai-panel input[type="url"], #mbx-ai-panel input[type="number"], #mbx-ai-panel select {
  width: 100%; min-height: 0; padding: 7px 8px; border-radius: 7px !important;
  background: color-mix(in srgb, var(--bg, #101114) 58%, var(--panel2, #202329)) !important;
  color: var(--text, #eceff3) !important; border: 1px solid var(--line, #333842) !important;
  font: 12px/1.4 "Segoe UI", Arial, sans-serif !important; outline: none;
}
#mbx-ai-panel textarea:focus, #mbx-ai-panel input:focus, #mbx-ai-panel select:focus { border-color: var(--accent, #6fc2ff) !important; }
#mbx-ai-panel textarea { resize: vertical; min-height: 64px; }
#mbx-ai-panel button {
  min-height: 26px; padding: 5px 9px; border-radius: 7px !important;
  background: var(--panel2, #202329) !important; color: var(--text, #eceff3) !important;
  border: 1px solid var(--line, #333842) !important; font: 600 11px/1.2 "Segoe UI", Arial, sans-serif !important;
  cursor: pointer;
}
#mbx-ai-panel button:hover { border-color: var(--accent, #6fc2ff) !important; }
#mbx-ai-panel button.mbx-ai-primary {
  background: color-mix(in srgb, var(--accent, #6fc2ff) 24%, var(--panel2, #202329)) !important;
  border-color: color-mix(in srgb, var(--accent, #6fc2ff) 60%, var(--line, #333842)) !important;
}
#mbx-ai-panel button:disabled { opacity: .55; cursor: default; }
#mbx-ai-panel .mbx-ai-row { display: flex; gap: 8px; align-items: end; flex-wrap: wrap; margin: 8px 0; }
#mbx-ai-panel .mbx-ai-row > label { flex: 1 1 110px; min-width: 0; margin: 0; color: var(--muted, #a5acb8); font-size: 10.5px; }
#mbx-ai-panel .mbx-ai-row > label input, #mbx-ai-panel .mbx-ai-row > label select { margin-top: 3px; }
#mbx-ai-panel .mbx-ai-check { display: flex; align-items: center; gap: 6px; color: var(--text, #eceff3) !important; font-size: 11px; flex: 1 1 160px; }
#mbx-ai-panel .mbx-ai-check input { width: auto; accent-color: var(--accent, #6fc2ff); }
#mbx-ai-panel .mbx-ai-actions { display: flex; gap: 6px; align-items: center; flex-wrap: wrap; margin: 8px 0; }
#mbx-ai-panel .mbx-ai-hint { color: var(--muted, #a5acb8); font-size: 10.5px; }
#mbx-ai-panel .mbx-ai-status { min-height: 16px; margin: 6px 0; color: var(--muted, #a5acb8); font-size: 10.5px; white-space: pre-wrap; }
#mbx-ai-panel .mbx-ai-status.is-error { color: var(--bad, #ff8d8d); }
#mbx-ai-panel .mbx-ai-status.is-good { color: var(--good, #86df9d); }
#mbx-ai-panel .mbx-ai-chips { display: flex; flex-wrap: wrap; gap: 4px; margin: 5px 0 8px; }
#mbx-ai-panel .mbx-ai-chip {
  border-radius: 999px !important; padding: 3px 8px !important; font-size: 10px !important;
  color: var(--muted, #a5acb8) !important; background: transparent !important;
}
#mbx-ai-panel .mbx-ai-chip:hover { color: var(--text, #eceff3) !important; border-color: var(--accent, #6fc2ff) !important; }
#mbx-ai-panel .mbx-ai-card {
  margin: 8px 0; padding: 9px 10px; border-radius: 9px;
  border: 1px solid var(--line, #333842);
  background: color-mix(in srgb, var(--panel2, #202329) 65%, transparent);
}
#mbx-ai-panel .mbx-ai-card strong { display: block; font-size: 12px; margin-bottom: 3px; }
#mbx-ai-panel .mbx-ai-card p { margin: 3px 0; color: var(--muted, #a5acb8); font-size: 11px; }
#mbx-ai-panel .mbx-ai-card .mbx-ai-actions { margin-bottom: 0; }
#mbx-ai-panel .mbx-ai-warn { color: var(--mbx-warn, #e9a13b); font-size: 10.5px; margin: 3px 0; }
#mbx-ai-panel .mbx-ai-tree {
  margin: 6px 0; padding: 6px 8px; border-radius: 7px; background: color-mix(in srgb, var(--bg, #101114) 50%, transparent);
  color: var(--muted, #a5acb8); font: 10px/1.5 "Consolas", monospace; max-height: 110px; overflow: auto; white-space: pre-wrap;
}
#mbx-ai-panel img.mbx-ai-result {
  display: block; width: 100%; max-height: 260px; object-fit: contain; border-radius: 8px;
  border: 1px solid var(--line, #333842); background: #0b0d10; margin: 7px 0;
}
#mbx-ai-panel .mbx-ai-keywarn {
  padding: 8px 9px; border-radius: 8px; margin: 0 0 9px;
  background: color-mix(in srgb, var(--mbx-warn, #e9a13b) 12%, var(--panel2, #202329));
  border: 1px solid color-mix(in srgb, var(--mbx-warn, #e9a13b) 45%, var(--line, #333842));
  color: var(--text, #eceff3); font-size: 11px;
}
#mbx-ai-panel .mbx-ai-keywarn[hidden] { display: none; }
#mbx-ai-panel .mbx-ai-keywarn button { margin-top: 6px; }
#mbx-ai-panel .mbx-ai-gallery { display: grid; grid-template-columns: repeat(4, 1fr); gap: 5px; margin-top: 6px; }
#mbx-ai-panel .mbx-ai-gallery figure { margin: 0; position: relative; }
#mbx-ai-panel .mbx-ai-gallery img { width: 100%; aspect-ratio: 1; object-fit: cover; border-radius: 6px; border: 1px solid var(--line, #333842); }
#mbx-ai-panel .mbx-ai-gallery button {
  position: absolute; top: 2px; right: 2px; width: 18px; height: 18px; min-height: 0; padding: 0;
  border-radius: 50% !important; font-size: 10px !important; line-height: 1;
  background: rgba(0,0,0,.65) !important; color: #fff !important; border-color: transparent !important;
}
#mbx-ai-panel .mbx-ai-gallery figcaption { color: var(--muted, #a5acb8); font-size: 8.5px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
#mbx-ai-panel .mbx-ai-sep { height: 1px; background: var(--line, #333842); margin: 12px 0; }
#mbx-ai-panel .mbx-ai-toggles { display: grid; gap: 4px; margin: 9px 0 4px; }
#mbx-ai-panel .mbx-ai-toggles label { display: flex; align-items: center; gap: 7px; color: var(--text, #eceff3); font-size: 11.5px; }
#mbx-ai-panel .mbx-ai-toggles input { width: auto; accent-color: var(--accent, #6fc2ff); }
#mbx-ai-panel .mbx-ai-badchips { display: flex; flex-wrap: wrap; gap: 4px; margin: 6px 0; }
#mbx-ai-panel .mbx-ai-badchip {
  padding: 3px 7px !important; border-radius: 999px !important; font-size: 10px !important;
  color: var(--bad, #ff8d8d) !important; border-color: color-mix(in srgb, var(--bad, #ff8d8d) 45%, var(--line, #333842)) !important;
  background: transparent !important;
}
#mbx-ai-panel .mbx-ai-statgrid { display: grid; grid-template-columns: 1fr 1fr; gap: 5px; margin: 6px 0; }
#mbx-ai-panel .mbx-ai-stat {
  padding: 7px 8px; border-radius: 7px; background: var(--panel2, #202329);
  border: 1px solid var(--line, #333842);
}
#mbx-ai-panel .mbx-ai-stat b { display: block; font-size: 14px; }
#mbx-ai-panel .mbx-ai-stat span { color: var(--muted, #a5acb8); font-size: 9.5px; }
#mbx-ai-panel .mbx-ai-settings-head { display: flex; align-items: center; justify-content: space-between; gap: 8px; margin-top: 2px; }
#mbx-ai-panel .mbx-ai-settings-head h3 { margin: 0; }
#mbx-ai-panel .mbx-ai-badge {
  flex: 0 0 auto; padding: 2px 7px; border-radius: 999px; border: 1px solid var(--line, #333842);
  color: var(--muted, #a5acb8); font-size: 9.5px; font-weight: 700; letter-spacing: .03em;
}
#mbx-ai-panel .mbx-ai-badge.is-good {
  color: var(--good, #86df9d); border-color: color-mix(in srgb, var(--good, #86df9d) 55%, var(--line, #333842));
  background: color-mix(in srgb, var(--good, #86df9d) 12%, transparent);
}
#mbx-ai-panel .mbx-ai-badge.is-warn { color: var(--mbx-warn, #e9a13b); border-color: color-mix(in srgb, var(--mbx-warn, #e9a13b) 45%, var(--line, #333842)); }
#mbx-ai-panel .mbx-ai-link { color: var(--accent, #6fc2ff); font-size: 10.5px; text-decoration: underline; text-underline-offset: 2px; }
#mbx-ai-panel .mbx-ai-modellist { display: grid; gap: 3px; margin-top: 6px; }
#mbx-ai-panel .mbx-ai-model {
  display: flex; align-items: center; gap: 6px; padding: 4px 6px; border-radius: 6px;
  background: var(--panel2, #202329); border: 1px solid color-mix(in srgb, var(--line, #333842) 70%, transparent);
  font-size: 9.5px; color: var(--muted, #a5acb8);
}
#mbx-ai-panel .mbx-ai-rank { flex: 0 0 auto; color: var(--accent, #6fc2ff); font-weight: 700; }
#mbx-ai-panel .mbx-ai-modelname { flex: 1 1 auto; min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
#mbx-ai-panel .mbx-ai-score { flex: 0 0 auto; color: var(--text, #eceff3); font-variant-numeric: tabular-nums; }
#mbx-ai-panel .mbx-ai-details { margin-top: 12px; padding-top: 9px; border-top: 1px solid var(--line, #333842); }
#mbx-ai-panel .mbx-ai-details summary { cursor: pointer; color: var(--text, #eceff3); font-size: 11px; font-weight: 600; }
#mbx-ai-panel .mbx-ai-details input { margin: 4px 0 8px; }

/* catalog decorations */
.itemRow .mbx-ai-pill, .itemTile .mbx-ai-pill {
  display: inline-block; margin-left: 5px; padding: 0 4px; border-radius: 4px;
  font: 700 9px/1.5 "Segoe UI", Arial, sans-serif; letter-spacing: .03em;
  color: #0b0d10; background: var(--accent, #6fc2ff); vertical-align: middle;
}
.itemRow .mbx-ai-banned, .itemTile .mbx-ai-banned {
  display: inline-block; margin-left: 5px; padding: 0 4px; border-radius: 4px;
  font: 700 9px/1.5 "Segoe UI", Arial, sans-serif; letter-spacing: .03em;
  color: #2a0b0b; background: var(--bad, #ff8d8d); vertical-align: middle;
}
.itemTile.mbx-banned { outline: 1px solid color-mix(in srgb, var(--bad, #ff8d8d) 65%, transparent); outline-offset: -2px; }
.mbx-hide-banned .itemRow.mbx-banned, .mbx-hide-banned .itemTile.mbx-banned { display: none !important; }
.itemTileVisual .mbx-ai-art {
  position: absolute; inset: 0; width: 100%; height: 100%; object-fit: cover;
  z-index: 1; pointer-events: none; border-radius: 4px;
}
.itemTileVisual .mbx-ai-flag {
  position: absolute; left: 3px; bottom: 3px; z-index: 2; pointer-events: none;
  padding: 0 4px; border-radius: 3px; font: 700 8px/1.6 "Segoe UI", Arial, sans-serif;
  color: #0b0d10; background: var(--accent, #6fc2ff);
}
.mbx-ai-profile { display: grid; gap: 5px; margin: 10px 0 8px; }
.mbx-ai-profile h3 { margin: 0 0 2px; }
.mbx-ai-profile .mbx-ai-prow { display: flex; align-items: baseline; justify-content: space-between; gap: 12px; font-size: 11.5px; }
.mbx-ai-profile .mbx-ai-prow b { font-weight: 700; text-align: right; overflow-wrap: anywhere; }
.mbx-ai-profile .mbx-ai-pkey { flex: none; color: var(--muted, #8a93a0); font-size: 9.5px; letter-spacing: .07em; text-transform: uppercase; }
.mbx-ai-profile .mbx-ai-pnote { color: var(--muted, #8a93a0); font-size: 10px; line-height: 1.45; margin: 4px 0 0; }
.mbx-ai-profile .mbx-ai-actions { margin-top: 6px; }
.mbx-ai-hint.is-error { color: #ff8d8d; }
#mbx-ai-panel { border-radius: 14px !important; }
html.mbx-revamp #mbx-ai-button { display: none !important; }
.mbx-ai-head { background: linear-gradient(135deg, color-mix(in srgb, var(--accent, #6fc2ff) 16%, var(--panel, #15181d)), var(--panel, #15181d) 65%); }
.mbx-ai-tabs { gap: 6px; padding: 8px 10px 0 !important; grid-template-columns: repeat(auto-fit, minmax(0, 1fr)) !important; }
.mbx-ai-tab { border-radius: 999px !important; padding: 6px 8px !important; border: 1px solid transparent !important; white-space: nowrap; }
.mbx-ai-tab.is-active { background: color-mix(in srgb, var(--accent, #6fc2ff) 22%, transparent) !important; border-color: var(--accent, #6fc2ff) !important; }
.mbx-ai-sig { padding: 0 12px 10px; color: var(--muted, #8a93a0); font: 10px/1.4 "Consolas", monospace; letter-spacing: .05em; opacity: .75; }
`;
    (document.head || document.documentElement).appendChild(styleEl);
  }

  function moveStyle() {
    if (styleEl && document.head) document.head.appendChild(styleEl);
  }

  /* ------------------------------------------------------------------ */
  /* Floating button + panel                                             */
  /* ------------------------------------------------------------------ */

  function ensureButton() {
    if (!state.enabled) {
      if (state.button) state.button.style.display = 'none';
      return;
    }
    if (!document.body || !$('.shell')) return;
    if (state.settings.aiButton === false) {
      if (state.button) state.button.style.display = 'none';
      return;
    }
    if (!state.button) {
      const button = document.createElement('button');
      button.id = 'mbx-ai-button';
      button.type = 'button';
      button.title = 'Mikeybox AI Studio (Alt+Shift+A)';
      button.setAttribute('aria-label', 'Open Mikeybox AI Studio');
      button.innerHTML = '<span>AI</span>';
      button.addEventListener('click', togglePanel);
      document.body.appendChild(button);
      state.button = button;
    }
    state.button.style.display = '';
  }

  function buildPanel() {
    if (state.panel || !document.body) return;
    const panel = document.createElement('div');
    panel.id = 'mbx-ai-panel';
    panel.setAttribute('role', 'dialog');
    panel.setAttribute('aria-label', 'Mikeybox AI Studio');
    panel.innerHTML = `
      <div class="mbx-ai-head">
        <div><strong>AI Studio</strong><small id="mbx-ai-sub">loading…</small></div>
        <div style="display:flex;gap:4px">
          <button type="button" class="mbx-ai-x" id="mbx-ai-settings" title="AI settings" aria-label="AI settings">⚙</button>
          <button type="button" class="mbx-ai-x" id="mbx-ai-close" title="Close" aria-label="Close AI Studio">×</button>
        </div>
      </div>
      <div class="mbx-ai-tabs" role="tablist">
        <button type="button" class="mbx-ai-tab is-active" data-view="build" role="tab" aria-selected="true">Build</button>
        <button type="button" class="mbx-ai-tab" data-view="data" role="tab" aria-selected="false">Data</button>
        <button type="button" class="mbx-ai-tab" data-view="settings" role="tab" aria-selected="false">Settings</button>
      </div>
      <div class="mbx-ai-body">
        <section class="mbx-ai-view" data-panel="build">
          <div class="mbx-ai-keywarn" id="mbx-ai-keywarn">
            Add your Gemini (or NVIDIA) API key to generate builds. It stays in this browser.
            <button type="button" id="mbx-ai-open-settings" class="mbx-ai-primary">Open AI settings</button>
          </div>
          <label class="mbx-ai-label" for="mbx-ai-prompt">Describe the invention</label>
          <textarea id="mbx-ai-prompt" rows="4" placeholder="A goop tank with a spinning turret, six wheels and a driver seat"></textarea>
          <div class="mbx-ai-chips" id="mbx-ai-ideas">
            <button type="button" class="mbx-ai-chip" data-idea="A goop tank with a spinning turret, six wheels and a driver seat">Goop tank</button>
            <button type="button" class="mbx-ai-chip" data-idea="A flying drone with four rotors, a camera and a small cargo basket">Drone</button>
            <button type="button" class="mbx-ai-chip" data-idea="A wearable robot suit with arms, a backpack core and shoulder cannons">Robot suit</button>
            <button type="button" class="mbx-ai-chip" data-idea="A fishing rig with rods, a chair, an umbrella and a storage box">Fishing rig</button>
          </div>
          <div class="mbx-ai-row">
            <label>Max parts<input type="number" id="mbx-ai-max" min="3" max="80" step="1" value="30"></label>
            <label class="mbx-ai-check"><input type="checkbox" id="mbx-ai-tidy" checked> Fill missing positions</label>
          </div>
          <div class="mbx-ai-actions">
            <button type="button" id="mbx-ai-build-go" class="mbx-ai-primary">Generate build</button>
            <span class="mbx-ai-hint" id="mbx-ai-modelhint">Add a key in settings</span>
          </div>
          <div class="mbx-ai-status" id="mbx-ai-build-status"></div>
          <div id="mbx-ai-build-result"></div>
        </section>

        <section class="mbx-ai-view" data-panel="data" hidden>
          <div class="mbx-ai-actions">
            <button type="button" id="mbx-ai-refresh">Refresh site data</button>
            <span class="mbx-ai-hint" id="mbx-ai-datastamp">Not loaded</span>
          </div>
          <p class="mbx-ai-hint" id="mbx-ai-siteinfo"></p>
          <div class="mbx-ai-profile" id="mbx-ai-profile"></div>
          <div id="mbx-ai-datacards"></div>
          <div id="mbx-ai-banned"></div>
          <div class="mbx-ai-toggles">
            <label><input type="checkbox" data-setting="markBanned"> Mark banned items in the catalog</label>
            <label><input type="checkbox" data-setting="hideBanned"> Hide banned items</label>
            <label><input type="checkbox" data-setting="showAiArt"> Show AI item art</label>
            <label><input type="checkbox" data-setting="streamer"> Streamer mode (hide my name)</label>
          </div>
          <p class="mbx-ai-hint">Live from /items.json, /api/build-security, /goop_build_policy.mjs, /api/site-status and /api/versions. Banned chips filter the catalog.</p>
        </section>

        <section class="mbx-ai-view" data-panel="settings" hidden>
          <div class="mbx-ai-settings-head">
            <h3>API key</h3>
            <span class="mbx-ai-badge" id="mbx-ai-key-badge">No key</span>
          </div>
          <p class="mbx-ai-hint">Paste a Gemini key (starts with AIza, free at aistudio.google.com/apikey) or an NVIDIA key (nvapi-). The key decides the provider; it is stored locally in this browser and used only by the extension worker.</p>
          <input type="password" id="mbx-ai-key" placeholder="AIza... (Gemini) or nvapi-... (NVIDIA)" autocomplete="off" spellcheck="false">
          <div class="mbx-ai-actions">
            <button type="button" id="mbx-ai-save-key" class="mbx-ai-primary">Save &amp; scan models</button>
            <button type="button" id="mbx-ai-clear-key">Clear</button>
            <a class="mbx-ai-link" id="mbx-ai-get-key" href="https://aistudio.google.com/apikey" target="_blank" rel="noopener">Get a Gemini key</a>
            <a class="mbx-ai-link" href="https://build.nvidia.com/settings/api-keys" target="_blank" rel="noopener">NVIDIA key</a>
          </div>
          <div class="mbx-ai-status" id="mbx-ai-key-status"></div>

          <div class="mbx-ai-sep"></div>

          <div class="mbx-ai-settings-head">
            <h3>Models</h3>
            <button type="button" id="mbx-ai-scan">Scan for best</button>
          </div>
          <p class="mbx-ai-hint">Scanning ranks every model your key can see and picks the strongest one that supports structured JSON.</p>
          <label class="mbx-ai-label" for="mbx-ai-chat-model">Build model</label>
          <select id="mbx-ai-chat-model"></select>
          <div class="mbx-ai-row">
            <label>Image model<input type="text" id="mbx-ai-image-model" list="mbx-ai-image-model-list" spellcheck="false" autocomplete="off"></label>
            <label>Image edit model<input type="text" id="mbx-ai-edit-model" spellcheck="false" autocomplete="off"></label>
          </div>
          <datalist id="mbx-ai-image-model-list"></datalist>
          <div class="mbx-ai-row">
            <label>3D model<input type="text" id="mbx-ai-3d-model" spellcheck="false" autocomplete="off"></label>
          </div>
          <div class="mbx-ai-status" id="mbx-ai-scan-status"></div>
          <div class="mbx-ai-hint" id="mbx-ai-scan-when">Never scanned</div>
          <div class="mbx-ai-modellist" id="mbx-ai-model-list"></div>

          <details class="mbx-ai-details">
            <summary>Advanced endpoints</summary>
            <label class="mbx-ai-label" for="mbx-ai-chat-base">Chat base URL</label>
            <input type="url" id="mbx-ai-chat-base" spellcheck="false">
            <label class="mbx-ai-label" for="mbx-ai-image-base">Image / 3D base URL</label>
            <input type="url" id="mbx-ai-image-base" spellcheck="false">
            <p class="mbx-ai-hint">FLUX image generation works on the hosted free tier. Image editing and TRELLIS 3D are downloadable NIMs, so point these at your own deployment to use them.</p>
            <button type="button" id="mbx-ai-save-endpoints">Save endpoints</button>
          </details>
        </section>

      </div>
      <div class="mbx-ai-sig" id="mbx-ai-sig">${(MBX && MBX.SIGNATURE) || ''}</div>
      <div class="mbx-ai-gate" id="mbx-ai-gate" hidden>
        <h2>Before you build</h2>
        <p><strong>Warning!</strong> The AI is extrenmely experimentle and WILL make mistakes.</p>
        <p class="mbx-ai-gate-note">Check every part, count and position in the editor before sending a build to the game.</p>
        <div class="mbx-ai-gate-actions">
          <button type="button" id="mbx-ai-gate-leave">Leave</button>
          <button type="button" id="mbx-ai-gate-continue" class="mbx-ai-primary">Continue</button>
        </div>
      </div>
    `;
    document.body.appendChild(panel);
    state.panel = panel;

    $('#mbx-ai-close', panel).addEventListener('click', closePanel);
    $('#mbx-ai-gate-leave', panel).addEventListener('click', closePanel);
    $('#mbx-ai-gate-continue', panel).addEventListener('click', () => {
      setWarningSeen();
      syncWarningGate();
      const prompt = $('#mbx-ai-prompt', panel);
      if (prompt) prompt.focus();
    });
    $('#mbx-ai-settings', panel).addEventListener('click', () => selectView('settings'));
    $('#mbx-ai-open-settings', panel).addEventListener('click', () => selectView('settings'));
    const imageList = $('#mbx-ai-image-model-list', panel);
    if (imageList) {
      CORE.IMAGE_MODELS.forEach((model) => {
        const option = document.createElement('option');
        option.value = model.id;
        option.label = model.label;
        imageList.appendChild(option);
      });
    }
    $('#mbx-ai-save-key', panel).addEventListener('click', saveAIKey);
    $('#mbx-ai-clear-key', panel).addEventListener('click', clearAIKey);
    $('#mbx-ai-scan', panel).addEventListener('click', scanModels);
    $('#mbx-ai-chat-model', panel).addEventListener('change', (event) => {
      state.aiSettings.chatModel = event.target.value;
      persistAISettings();
      syncHeader();
    });
    ['mbx-ai-image-model', 'mbx-ai-edit-model', 'mbx-ai-3d-model'].forEach((id) => {
      $('#' + id, panel).addEventListener('change', () => {
        state.aiSettings.imageModel = $('#mbx-ai-image-model', panel).value.trim();
        state.aiSettings.editModel = $('#mbx-ai-edit-model', panel).value.trim();
        state.aiSettings.model3d = $('#mbx-ai-3d-model', panel).value.trim();
        persistAISettings();
      });
    });
    $('#mbx-ai-save-endpoints', panel).addEventListener('click', () => {
      state.aiSettings.chatBase = $('#mbx-ai-chat-base', panel).value.trim();
      state.aiSettings.imageBase = $('#mbx-ai-image-base', panel).value.trim();
      persistAISettings().then((response) => {
        if (response && response.ok) setScanStatus('Endpoints saved.', 'good');
      });
    });
    $$('.mbx-ai-tab', panel).forEach((tab) => {
      tab.addEventListener('click', () => selectView(tab.dataset.view));
    });
    $$('#mbx-ai-ideas .mbx-ai-chip', panel).forEach((chip) => {
      chip.addEventListener('click', () => {
        $('#mbx-ai-prompt', panel).value = chip.dataset.idea;
        $('#mbx-ai-prompt', panel).focus();
      });
    });
    $('#mbx-ai-build-go', panel).addEventListener('click', generateBuild);
    $('#mbx-ai-refresh', panel).addEventListener('click', () => loadSiteData(true).then(renderData).then(renderProfile));
    $$('#mbx-ai-panel [data-setting]', panel).forEach((input) => {
      input.addEventListener('change', () => {
        updateSetting(input.dataset.setting, input.checked);
        state.settings[input.dataset.setting] = input.checked;
        applyCatalogDecorations();
        if (input.dataset.setting === 'streamer') {
          syncSignature();
          if (state.profile) renderProfile();
        }
      });
    });

    syncControls();
    syncHeader();
    renderSettings();
    renderLastBuild();
    renderLastBuild();
    renderGallery();
    if (!state.keyConfigured) refreshStatus();
  }

  function syncControls() {
    if (!state.panel) return;
    const tidy = $('#mbx-ai-tidy', state.panel);
    if (tidy) tidy.checked = state.settings.autoArrange !== false;
    $$('#mbx-ai-panel [data-setting]', state.panel).forEach((input) => {
      input.checked = Boolean(state.settings[input.dataset.setting]);
    });
    syncSignature();
  }

  function streamerOn() {
    return Boolean(state.settings && state.settings.streamer);
  }

  /* The studio footer carries the build signature, so streamer mode masks it
     there too - a shared screen never shows the Prime id. */
  function syncSignature() {
    if (!state.panel) return;
    const sig = $('#mbx-ai-sig', state.panel);
    if (!sig) return;
    sig.textContent = streamerOn()
      ? MBX.maskSignature(MBX.SIGNATURE, true)
      : ((MBX && MBX.SIGNATURE) || '');
  }

  function selectView(view) {
    state.view = view;
    $$('.mbx-ai-tab', state.panel).forEach((tab) => {
      const on = tab.dataset.view === view;
      tab.classList.toggle('is-active', on);
      tab.setAttribute('aria-selected', on ? 'true' : 'false');
    });
    $$('.mbx-ai-view', state.panel).forEach((sec) => {
      sec.hidden = sec.dataset.panel !== view;
    });
    if (view === 'data') {
      loadSiteData(false).then(renderData).then(renderProfile);
    }
    if (view === 'settings') renderSettings();
  }

  /* The warning is shown once per browser session: Continue acknowledges it,
     Leave closes the studio, and a new tab or browser run asks again. */
  const WARNING_KEY = 'mbxAiWarningSeen';

  function warningSeen() {
    try {
      return sessionStorage.getItem(WARNING_KEY) === '1';
    } catch (err) {
      return false;
    }
  }

  function setWarningSeen() {
    try {
      sessionStorage.setItem(WARNING_KEY, '1');
    } catch (err) {
      /* storage blocked: the warning simply shows again next open */
    }
  }

  function syncWarningGate() {
    if (!state.panel) return;
    const gate = $('#mbx-ai-gate', state.panel);
    if (gate) gate.hidden = warningSeen();
  }

  function openPanel() {
    buildPanel();
    if (!state.panel) return;
    state.panel.classList.add('mbx-open');
    syncWarningGate();
    syncHeader();
    if (state.view === 'data') loadSiteData(false).then(renderData);
    refreshStatus();
  }

  function closePanel() {
    if (state.panel) state.panel.classList.remove('mbx-open');
  }

  function togglePanel() {
    if (!state.panel || !state.panel.classList.contains('mbx-open')) openPanel();
    else closePanel();
  }

  /* ------------------------------------------------------------------ */
  /* AI settings: key, models, endpoints                                 */
  /* ------------------------------------------------------------------ */

  function setKeyStatus(text, type) {
    const el = $('#mbx-ai-key-status', state.panel);
    if (!el) return;
    el.textContent = text || '';
    el.classList.toggle('is-error', type === 'error');
    el.classList.toggle('is-good', type === 'good');
  }

  function setScanStatus(text, type) {
    const el = $('#mbx-ai-scan-status', state.panel);
    if (!el) return;
    el.textContent = text || '';
    el.classList.toggle('is-error', type === 'error');
    el.classList.toggle('is-good', type === 'good');
  }

  function modelOptions() {
    const list = Array.isArray(state.aiSettings.scannedModels) ? state.aiSettings.scannedModels : [];
    const options = [{ id: CORE.AUTO_MODEL, auto: true, context: 0 }];
    const seen = new Set([CORE.AUTO_MODEL]);
    list.forEach((model) => {
      const id = typeof model === 'string' ? model : model && model.id;
      if (!id || seen.has(id)) return;
      seen.add(id);
      options.push({
        id: id,
        context: (model && model.context) || 0,
        vision: Boolean(model && model.vision),
        structured: Boolean(model && model.structured),
      });
    });
    if (state.aiSettings.chatModel && !seen.has(state.aiSettings.chatModel)) {
      options.unshift({ id: state.aiSettings.chatModel, context: 0 });
    }
    return options;
  }

  function renderSettings() {
    if (!state.panel) return;
    const badge = $('#mbx-ai-key-badge', state.panel);
    if (badge) {
      badge.textContent = state.keyConfigured ? 'Key saved' : 'No key';
      badge.classList.toggle('is-good', state.keyConfigured);
      badge.classList.toggle('is-warn', !state.keyConfigured);
    }
    const select = $('#mbx-ai-chat-model', state.panel);
    if (select) {
      const current = state.aiSettings.chatModel || CORE.AUTO_MODEL;
      select.textContent = '';
      modelOptions().forEach((model) => {
        const option = document.createElement('option');
        option.value = model.id;
        if (model.auto) {
          option.textContent = 'Auto — best available model (recommended)';
        } else {
          const bits = [];
          if (model.context) bits.push(Math.round(model.context / 1024) + 'k ctx');
          if (model.vision) bits.push('vision');
          if (model.structured) bits.push('JSON');
          option.textContent = model.id + (bits.length ? ' — ' + bits.join(' · ') : '');
        }
        select.appendChild(option);
      });
      select.value = current;
    }
    const image = $('#mbx-ai-image-model', state.panel);
    if (image && document.activeElement !== image) {
      image.value = state.aiSettings.imageModel || (CORE.IMAGE_MODELS[0] && CORE.IMAGE_MODELS[0].id) || '';
    }
    const edit = $('#mbx-ai-edit-model', state.panel);
    if (edit) edit.value = state.aiSettings.editModel || '';
    const three = $('#mbx-ai-3d-model', state.panel);
    if (three) three.value = state.aiSettings.model3d || '';
    const chatBase = $('#mbx-ai-chat-base', state.panel);
    if (chatBase) chatBase.value = state.aiSettings.chatBase || '';
    const imageBase = $('#mbx-ai-image-base', state.panel);
    if (imageBase) imageBase.value = state.aiSettings.imageBase || '';
    const when = $('#mbx-ai-scan-when', state.panel);
    if (when) {
      when.textContent = state.aiSettings.lastScanAt ? 'Last scan ' + new Date(state.aiSettings.lastScanAt).toLocaleString() : 'Never scanned';
    }
    renderModelList();
  }

  function renderModelList() {
    const wrap = $('#mbx-ai-model-list', state.panel);
    if (!wrap) return;
    wrap.textContent = '';
    const list = (Array.isArray(state.aiSettings.scannedModels) ? state.aiSettings.scannedModels : []).slice(0, 8);
    list.forEach((model, index) => {
      const row = document.createElement('div');
      row.className = 'mbx-ai-model';
      const rank = document.createElement('span');
      rank.className = 'mbx-ai-rank';
      rank.textContent = '#' + (index + 1);
      const name = document.createElement('span');
      name.className = 'mbx-ai-modelname';
      name.textContent = typeof model === 'string' ? model : model.id;
      name.title = name.textContent;
      row.appendChild(rank);
      row.appendChild(name);
      if (model && model.score) {
        const score = document.createElement('span');
        score.className = 'mbx-ai-score';
        score.textContent = String(model.score);
        row.appendChild(score);
      }
      wrap.appendChild(row);
    });
  }

  function applyScanResult(scan) {
    if (!scan) return;
    const auto = !state.aiSettings.chatModel || state.aiSettings.chatModel === CORE.AUTO_MODEL;
    state.aiSettings.scannedModels = scan.models || [];
    state.aiSettings.lastScanAt = Date.now();
    /* Auto stays auto: the worker ranks the key's models on every build, so a
       scan only refreshes the shortlist instead of pinning one model. */
    if (auto) state.aiSettings.chatModel = CORE.AUTO_MODEL;
    else if (scan.selected) state.aiSettings.chatModel = scan.selected;
    else if (scan.recommended) state.aiSettings.chatModel = scan.recommended;
  }

  function persistAISettings() {
    return send('mbx-ai-save-settings', { settings: state.aiSettings }, 15000).then((response) => {
      if (!response || !response.ok) {
        setScanStatus((response && response.error) || 'Could not save AI settings.', 'error');
      }
      return response;
    });
  }

  async function saveAIKey() {
    const input = $('#mbx-ai-key', state.panel);
    const key = (input && input.value ? input.value : '').trim();
    if (!key) {
      setKeyStatus('Paste a Gemini or NVIDIA key first.', 'error');
      return;
    }
    if (settingsBusy) return;
    settingsBusy = true;
    const button = $('#mbx-ai-save-key', state.panel);
    if (button) button.disabled = true;
    setKeyStatus('Saving the key and scanning models…');
    const response = await send('mbx-ai-set-key', { key: key }, 120000);
    settingsBusy = false;
    if (button) button.disabled = false;
    if (!response || !response.ok) {
      setKeyStatus((response && response.error) || 'Could not save the key.', 'error');
      return;
    }
    state.keyConfigured = true;
    if (response.provider) state.aiSettings.provider = response.provider;
    if (response.chatModel) state.aiSettings.chatModel = response.chatModel;
    if (input) input.value = '';
    const scan = response.scan;
    if (scan && scan.ok) {
      applyScanResult(scan);
      if (scan.rejected) {
        setKeyStatus('Key saved, but ' + providerName() + ' rejected it: ' + (scan.warning || 'unauthorised') + '. Check the key and try again.', 'error');
      } else if (scan.warning) {
        setKeyStatus('Key saved. Model listing was unavailable, so the built-in shortlist was used.', 'error');
      } else {
        setKeyStatus('Key saved. Best model selected: ' + (scan.recommended || 'none'), 'good');
      }
    } else {
      setKeyStatus('Key saved, but the model scan failed: ' + ((scan && scan.error) || 'unknown error'), 'error');
    }
    renderSettings();
    syncHeader();
  }

  async function clearAIKey() {
    const response = await send('mbx-ai-clear-key', {}, 15000);
    if (response && response.ok) {
      state.keyConfigured = false;
      setKeyStatus('Key removed.', 'good');
    } else {
      setKeyStatus((response && response.error) || 'Could not remove the key.', 'error');
    }
    renderSettings();
    syncHeader();
  }

  async function scanModels() {
    if (settingsBusy) return;
    settingsBusy = true;
    const button = $('#mbx-ai-scan', state.panel);
    if (button) button.disabled = true;
    setScanStatus('Scanning available ' + providerName() + ' models…');
    const response = await send('mbx-ai-scan', {}, 90000);
    settingsBusy = false;
    if (button) button.disabled = false;
    if (!response || !response.ok) {
      setScanStatus((response && response.error) || 'Scan failed.', 'error');
      return;
    }
    applyScanResult(response);
    const models = Array.isArray(response.models) ? response.models : [];
    if (response.rejected) {
      setScanStatus(providerName() + ' rejected the saved key: ' + (response.warning || 'unauthorised') + '. Paste a new key above.', 'error');
    } else if (response.usedFallback) {
      setScanStatus('Used the built-in shortlist: ' + (response.warning || 'model listing was unavailable') + '.', 'error');
    } else {
      const auto = !state.aiSettings.chatModel || state.aiSettings.chatModel === CORE.AUTO_MODEL;
      setScanStatus('Ranked ' + models.length + ' models. ' + (auto
        ? 'Auto will build with ' + (response.recommended || 'the best model') + '.'
        : 'Selected ' + (response.selected || response.recommended) + '.'), 'good');
    }
    renderSettings();
    syncHeader();
  }

  /* ------------------------------------------------------------------ */
  /* Site data                                                           */
  /* ------------------------------------------------------------------ */

  async function loadSiteData(force) {
    if (!force && state.catalog.length && Date.now() - state.dataAt < 5 * 60 * 1000) return;
    if (state.dataPromise) return state.dataPromise;

    state.dataPromise = (async () => {
      const [itemsRes, securityRes, policyRes, siteRes, versionsRes] = await Promise.allSettled([
        fetch('/items.json', { cache: 'no-store' }).then((r) => (r.ok ? r.json() : Promise.reject(new Error('items.json ' + r.status)))),
        fetch('/api/build-security', { cache: 'no-store' }).then((r) => (r.ok ? r.json() : null)).catch(() => null),
        fetch('/goop_build_policy.mjs', { cache: 'no-store' }).then((r) => (r.ok ? r.text() : '')).catch(() => ''),
        fetch('/api/site-status', { cache: 'no-store' }).then((r) => (r.ok ? r.json() : null)).catch(() => null),
        fetch('/api/versions', { cache: 'no-store' }).then((r) => (r.ok ? r.json() : null)).catch(() => null),
      ]);

      state.site = siteRes.status === 'fulfilled' && siteRes.value && siteRes.value.data ? siteRes.value.data : null;
      state.versions = versionsRes.status === 'fulfilled' ? versionsRes.value : null;

      if (itemsRes.status === 'fulfilled' && itemsRes.value) {
        const data = itemsRes.value;
        const source = Array.isArray(data.catalog) ? data.catalog : Object.values(data.catalog || {});
        const seen = new Set();
        state.catalog = source.filter((item) => {
          if (!item || !item.id || seen.has(item.id)) return false;
          seen.add(item.id);
          return true;
        }).map((item) => ({ id: item.id, name: item.name || item.id, category: item.category || '' }))
          .sort((a, b) => a.name.localeCompare(b.name));
        state.categoryCounts = {};
        for (const item of state.catalog) {
          state.categoryCounts[item.category || 'Other'] = (state.categoryCounts[item.category || 'Other'] || 0) + 1;
        }
        const banned = new Set(Array.isArray(data.banned) ? data.banned : []);
        if (securityRes.status === 'fulfilled' && securityRes.value && securityRes.value.data) {
          state.security = securityRes.value.data;
          for (const id of state.security.itemBlacklist || []) banned.add(id);
          state.blacklist = new Set(state.security.itemBlacklist || []);
        } else {
          state.security = null;
          state.blacklist = new Set();
        }
        state.banned = banned;
        state.dataAt = Date.now();
      }

      if (policyRes.status === 'fulfilled' && policyRes.value) {
        const text = policyRes.value;
        const readNumber = (name) => {
          const match = text.match(new RegExp(name + '\\s*:\\s*(\\d+)'));
          return match ? Number(match[1]) : null;
        };
        const policy = {
          maxDescendants: readNumber('maxDescendants'),
          maxContentsPerContainer: readNumber('maxContentsPerContainer'),
          maxContentsDepth: readNumber('maxContentsDepth'),
          maxCountInBlueprint: readNumber('maxCountInBlueprint'),
        };
        state.policy = Object.values(policy).some((value) => value !== null) ? policy : null;
      }

      populateItemSelect();
      applyCatalogDecorations();
      state.dataPromise = null;
      renderData();
    })().catch((err) => {
      state.dataPromise = null;
      const status = state.panel && $('#mbx-ai-build-status', state.panel);
      if (status) setStatus(status, 'Could not read the editor catalog: ' + err.message, 'error');
    });

    return state.dataPromise;
  }

  function populateItemSelect() {
    if (!state.panel) return;
    const select = $('#mbx-ai-itemtarget', state.panel);
    if (!select || !state.catalog.length) return;
    const previous = select.value;
    let selected = previous;
    if (!selected) {
      const raw = ($('#selectionName') && $('#selectionName').textContent || '').trim();
      const id = raw.startsWith('item_') ? raw.split('#')[0] : '';
      selected = state.catalog.some((item) => item.id === id) ? id : '';
    }
    select.innerHTML = '';
    state.catalog.forEach((item) => {
      const option = document.createElement('option');
      option.value = item.id;
      option.textContent = item.name + ' — ' + item.id;
      select.appendChild(option);
    });
    if (selected && state.catalog.some((item) => item.id === selected)) select.value = selected;
  }

  function renderData() {
    if (!state.panel) return;
    const cards = $('#mbx-ai-datacards', state.panel);
    const stamp = $('#mbx-ai-datastamp', state.panel);
    if (!cards) return;
    if (!state.catalog.length) {
      cards.innerHTML = '<div class="mbx-ai-status">Catalog not loaded yet.</div>';
      return;
    }
    if (stamp) stamp.textContent = 'Updated ' + new Date(state.dataAt).toLocaleTimeString();
    const site = state.site || {};
    const versions = state.versions || {};
    const siteInfo = state.panel && $('#mbx-ai-siteinfo', state.panel);
    if (siteInfo) {
      const bits = [];
      if (site.mode) bits.push('Mode: ' + site.mode);
      if (versions.site && versions.site.gameVersion) bits.push('Game ' + versions.site.gameVersion);
      if (versions.site && versions.site.buildId) bits.push('Build ' + versions.site.buildId);
      if (versions.padHost && versions.padHost.live) bits.push('Prime pad live · ' + (versions.padHost.players || 0) + ' players');
      if (site.banner) bits.push('Banner: ' + site.banner);
      siteInfo.textContent = bits.join('  ·  ') || 'Site status unavailable.';
    }
    const security = state.security || {};
    const level = security.level || 'unknown';
    const platform = security.platformLevels ? Object.entries(security.platformLevels).map(([k, v]) => k + ': ' + v).join(' · ') : '—';
    const black = (security.itemBlacklist || []).length;
    const allow = security.itemAllowlist && typeof security.itemAllowlist === 'object' ? Object.keys(security.itemAllowlist).length : 0;
    const policy = state.policy || {};
    const cats = Object.keys(state.categoryCounts).length;
    cards.innerHTML = '';
    const stats = [
      [state.catalog.length, 'catalog items'],
      [cats, 'categories'],
      [level, 'build security'],
      [state.banned.size, 'banned items'],
      [black + ' / ' + allow, 'blacklist / allowlist'],
      [policy.maxDescendants == null ? '—' : policy.maxDescendants, 'max parts'],
      [policy.maxContentsPerContainer == null ? '—' : policy.maxContentsPerContainer, 'container contents'],
      [policy.maxContentsDepth == null ? '—' : policy.maxContentsDepth, 'nesting depth'],
    ];
    const grid = document.createElement('div');
    grid.className = 'mbx-ai-statgrid';
    for (const [value, label] of stats) {
      const cell = document.createElement('div');
      cell.className = 'mbx-ai-stat';
      const b = document.createElement('b');
      b.textContent = String(value);
      const span = document.createElement('span');
      span.textContent = label;
      cell.appendChild(b);
      cell.appendChild(span);
      grid.appendChild(cell);
    }
    cards.appendChild(grid);
    const note = document.createElement('p');
    note.className = 'mbx-ai-hint';
    note.textContent = 'Platform levels — ' + platform + (policy.maxCountInBlueprint == null ? '' : ' · ' + policy.maxCountInBlueprint + ' copies allowed per build');
    cards.appendChild(note);

    const bannedWrap = $('#mbx-ai-banned', state.panel);
    if (bannedWrap) {
      bannedWrap.innerHTML = '';
      const heading = document.createElement('h3');
      heading.textContent = 'Banned items';
      bannedWrap.appendChild(heading);
      if (!state.banned.size) {
        const p = document.createElement('p');
        p.className = 'mbx-ai-hint';
        p.textContent = 'No banned items reported right now.';
        bannedWrap.appendChild(p);
      } else {
        const chips = document.createElement('div');
        chips.className = 'mbx-ai-badchips';
        for (const id of state.banned) {
          const chip = document.createElement('button');
          chip.type = 'button';
          chip.className = 'mbx-ai-badchip';
          chip.textContent = id;
          chip.title = 'Filter the catalog for ' + id;
          chip.addEventListener('click', () => filterCatalog(id));
          chips.appendChild(chip);
        }
        bannedWrap.appendChild(chips);
      }
    }
    if (state.panel) syncControls();
  }

  /* ------------------------------------------------------------------ */
  /* You on Prime — read from the editor's own keys, never tokens        */
  /* ------------------------------------------------------------------ */

  function readStored(store, key) {
    try {
      return store.getItem(key) || '';
    } catch (err) {
      return '';
    }
  }

  function profileRow(label, value) {
    const row = document.createElement('div');
    row.className = 'mbx-ai-prow';
    const key = document.createElement('span');
    key.className = 'mbx-ai-pkey';
    key.textContent = label;
    const val = document.createElement('b');
    val.textContent = value || '—';
    val.title = value || '';
    row.appendChild(key);
    row.appendChild(val);
    return row;
  }

  function copyToClipboard(text, note) {
    if (!navigator.clipboard || !navigator.clipboard.writeText) {
      setStatus(note, 'Clipboard unavailable in this browser.', 'error');
      return;
    }
    navigator.clipboard.writeText(text)
      .then(() => setStatus(note, 'Copied.', 'good'))
      .catch(() => setStatus(note, 'Copy failed.', 'error'));
  }

  async function renderProfile() {
    if (!state.panel) return;
    const wrap = $('#mbx-ai-profile', state.panel);
    if (!wrap) return;
    state.profile = {
      recentPlayerNames: readStored(localStorage, 'mikeybox_recent_player_names'),
      platform: readStored(localStorage, 'mikeybox_platform'),
      layout: readStored(localStorage, 'mikeybox_editor_layout_v1'),
      toolTab: readStored(localStorage, 'mikeybox_editor_tool_tab_v1'),
      handTracking: readStored(localStorage, 'mikeybox_hand_tracking_profile'),
      recovery: readStored(sessionStorage, 'mikeybox_goop_recovery_session_v1'),
    };
    drawProfile(wrap);
  }

  function drawProfile(wrap) {
    const data = state.profile || {};
    const names = CORE.playerNamesFrom(data.recentPlayerNames);
    const hidden = streamerOn();
    const versions = state.versions || {};
    const padLive = versions.padHost && versions.padHost.live;
    wrap.textContent = '';

    const heading = document.createElement('h3');
    heading.textContent = 'You on Prime';
    wrap.appendChild(heading);

    wrap.appendChild(profileRow('In-game username', hidden
      ? (names[0] ? MBX.STREAMER_NAME : 'hidden')
      : (names[0] || 'not set yet')));
    if (names.length > 1) {
      wrap.appendChild(profileRow('Recent names', hidden ? MBX.STREAMER_MASK : names.slice(1).join(' · ')));
    }
    wrap.appendChild(profileRow('Platform', (data.platform || 'quest') === 'steam' ? 'SteamVR' : 'Quest'));
    if (padLive) wrap.appendChild(profileRow('Prime pad', (Number(versions.padHost.players) || 0) + ' players in room'));
    if (data.layout) wrap.appendChild(profileRow('Editor layout', data.layout));
    if (data.toolTab) wrap.appendChild(profileRow('Tool tab', data.toolTab));
    if (data.handTracking) wrap.appendChild(profileRow('Hand tracking', data.handTracking));
    if (data.recovery) {
      wrap.appendChild(profileRow('Recovery session', hidden ? MBX.STREAMER_MASK : String(data.recovery).slice(0, 8)));
    }

    const actions = document.createElement('div');
    actions.className = 'mbx-ai-actions';
    const note = document.createElement('p');
    note.className = 'mbx-ai-pnote';

    const copyName = document.createElement('button');
    copyName.type = 'button';
    copyName.textContent = 'Copy username';
    copyName.disabled = !names.length;
    copyName.addEventListener('click', () => copyToClipboard(hidden ? MBX.STREAMER_NAME : (names[0] || ''), note));

    const copyDossier = document.createElement('button');
    copyDossier.type = 'button';
    copyDossier.className = 'mbx-ai-primary';
    copyDossier.textContent = 'Copy dossier';
    copyDossier.addEventListener('click', () => {
      const dossier = CORE.dossierFrom({
        host: location.hostname,
        site: state.site,
        versions: state.versions,
        recentPlayerNames: data.recentPlayerNames,
        platform: data.platform,
        layout: data.layout,
        toolTab: data.toolTab,
        handTracking: data.handTracking,
        recoverySession: data.recovery,
        signature: (MBX && MBX.SIGNATURE) || '',
        streamer: hidden,
        ai: {
          model: state.aiSettings.chatModel || CORE.AUTO_MODEL,
          lastBuild: state.lastBuild ? state.lastBuild.name : '',
        },
      });
      copyToClipboard(JSON.stringify(dossier, null, 2), note);
    });

    actions.appendChild(copyName);
    actions.appendChild(copyDossier);
    wrap.appendChild(actions);

    note.textContent = hidden
      ? 'Streamer mode is on: the username, recent names, recovery session and build signature are masked on screen and in the copied dossier. Tokens and cookies are never read.'
      : 'Read from this browser: mikeybox_recent_player_names, mikeybox_platform and the editor layout keys. Tokens and cookies are never read.';
    wrap.appendChild(note);
  }

  function filterCatalog(id) {
    const search = $('#itemSearch');
    if (!search) return;
    search.value = id;
    search.dispatchEvent(new Event('input', { bubbles: true }));
    search.focus();
  }

  /* ------------------------------------------------------------------ */
  /* Catalog decorations: AI art + banned markers                        */
  /* ------------------------------------------------------------------ */

  function rowItemId(row) {
    const first = row.firstElementChild;
    const text = first ? (first.textContent || '').trim() : '';
    return text.startsWith('item_') ? text.split(/[\s#]/)[0] : '';
  }

  function applyCatalogDecorations() {
    if (!document.body) return;
    if (!state.enabled) {
      clearDecorations();
      return;
    }
    if (state.panel) syncControls();
    const root = document.documentElement;
    root.classList.toggle('mbx-hide-banned', Boolean(state.settings.hideBanned));
    const showArt = state.settings.showAiArt !== false;
    const mark = state.settings.markBanned !== false;

    $$('.itemTile').forEach((tile) => {
      const id = tile.dataset.itemId || '';
      const visual = tile.querySelector('.itemTileVisual');
      const existing = tile.querySelector('.mbx-ai-art');
      const art = showArt && id ? state.art[id] : null;
      if (art && visual) {
        if (!existing) {
          const img = document.createElement('img');
          img.className = 'mbx-ai-art';
          img.alt = '';
          img.src = art.dataUrl;
          visual.appendChild(img);
        } else if (existing.src !== art.dataUrl) {
          existing.src = art.dataUrl;
        }
        if (!tile.querySelector('.mbx-ai-flag')) {
          const flag = document.createElement('span');
          flag.className = 'mbx-ai-flag';
          flag.textContent = 'AI';
          visual.appendChild(flag);
        }
      } else {
        if (existing) existing.remove();
        const flag = tile.querySelector('.mbx-ai-flag');
        if (flag) flag.remove();
      }
      decorateBanned(tile, id, mark);
    });

    $$('.itemRow').forEach((row) => {
      const id = rowItemId(row);
      const first = row.firstElementChild;
      const hasArt = showArt && id && state.art[id];
      const pill = row.querySelector('.mbx-ai-pill');
      if (hasArt && first && !pill) {
        const span = document.createElement('span');
        span.className = 'mbx-ai-pill';
        span.textContent = 'AI';
        span.title = 'AI art attached to ' + id;
        first.appendChild(span);
      } else if (!hasArt && pill) {
        pill.remove();
      }
      decorateBanned(row, id, mark);
    });
  }

  function decorateBanned(node, id, mark) {
    const isBanned = id && state.banned.has(id) && (mark || state.settings.hideBanned);
    node.classList.toggle('mbx-banned', Boolean(isBanned));
    const existing = node.querySelector('.mbx-ai-banned');
    if (mark && isBanned && !existing) {
      const badge = document.createElement('span');
      badge.className = 'mbx-ai-banned';
      badge.textContent = 'BANNED';
      badge.title = id + ' is banned by the current build rules';
      const host = node.classList.contains('itemRow') ? node.firstElementChild : node;
      if (host) host.appendChild(badge);
    } else if (!isBanned && existing) {
      existing.remove();
    }
  }

  /* ------------------------------------------------------------------ */
  /* Build                                                               */
  /* ------------------------------------------------------------------ */

  function setStatus(node, text, type) {
    if (!node) return;
    node.textContent = text || '';
    node.classList.toggle('is-error', type === 'error');
    node.classList.toggle('is-good', type === 'good');
  }

  function busy(button, on, label) {
    state.busy = on;
    if (button) {
      button.disabled = on;
      if (on) {
        button.dataset.label = button.textContent;
        button.textContent = label || 'Working…';
      } else if (button.dataset.label) {
        button.textContent = button.dataset.label;
      }
    }
  }

  async function generateBuild() {
    if (!state.panel) return;
    const button = $('#mbx-ai-build-go', state.panel);
    const status = $('#mbx-ai-build-status', state.panel);
    const prompt = ($('#mbx-ai-prompt', state.panel).value || '').trim();
    if (!prompt) {
      setStatus(status, 'Describe what you want to build.', 'error');
      return;
    }
    if (!state.keyConfigured) {
      setStatus(status, 'Add a Gemini or NVIDIA API key in AI Studio → Settings first.', 'error');
      return;
    }
    if (!state.catalog.length) {
      setStatus(status, 'Loading the item catalog…');
      await loadSiteData(false);
      if (!state.catalog.length) {
        setStatus(status, 'The item catalog could not be loaded.', 'error');
        return;
      }
    }
    const maxParts = Math.min(80, Math.max(3, Number($('#mbx-ai-max', state.panel).value) || 30));
    const autoArrange = $('#mbx-ai-tidy', state.panel).checked;
    const asking = state.aiSettings.chatModel && state.aiSettings.chatModel !== CORE.AUTO_MODEL ? state.aiSettings.chatModel : 'the best model';
    setStatus(status, 'Asking ' + asking + ' for a build…');
    busy(button, true, 'Generating…');
    try {
      const response = await send('mbx-ai-build', {
        payload: {
          prompt: prompt,
          items: state.catalog,
          categories: Object.keys(state.categoryCounts),
          banned: Array.from(state.banned),
          maxParts: maxParts,
          autoArrange: autoArrange,
          fallbackRootId: 'item_backpack',
          model: state.aiSettings.chatModel || '',
        },
      }, 340000);
      if (!response || !response.ok) {
        setStatus(status, (response && response.error) || 'Generation failed.', 'error');
        return;
      }
      state.lastBuild = response.invention;
      localSet({ mbxAiLastBuild: response.invention });
      setStatus(status, 'Generated with ' + (response.model || providerName()) + (response.note ? ' · ' + response.note : '') + '.', 'good');
      renderLastBuild();
    } finally {
      busy(button, false);
    }
  }

  /* Used by the quick panel's "Surprise me": open Build with a ready prompt. */
  function setPrompt(text) {
    buildPanel();
    if (!state.panel) return;
    const box = $('#mbx-ai-prompt', state.panel);
    if (box) box.value = String(text || '').slice(0, 2000);
    openPanel();
    selectView('build');
    if (box) box.focus();
  }

  function renderLastBuild() {
    if (!state.panel) return;
    const wrap = $('#mbx-ai-build-result', state.panel);
    if (!wrap) return;
    wrap.innerHTML = '';
    const build = state.lastBuild;
    if (!build || !build.root) return;
    const card = document.createElement('div');
    card.className = 'mbx-ai-card';
    const title = document.createElement('strong');
    title.textContent = build.name || 'AI invention';
    card.appendChild(title);
    if (build.summary) {
      const p = document.createElement('p');
      p.textContent = build.summary;
      card.appendChild(p);
    }
    const meta = document.createElement('p');
    meta.textContent = (build.stats ? build.stats.nodes : countNodes(build.root)) + ' parts · ' + ((build.stats ? build.stats.stuckLinks : countNodes(build.root) - 1)) + ' goop links';
    card.appendChild(meta);
    if (build.quality) {
      const check = document.createElement('p');
      const stats = build.quality.stats || {};
      check.className = build.quality.score >= 70 ? 'mbx-ai-hint' : 'mbx-ai-warn';
      check.textContent = 'Shape check ' + build.quality.score + '/100 · ' + (build.quality.plan || 'invention')
        + ' · wing/axle pairs ' + (stats.mirroredPairs || 0)
        + ' · span ' + (stats.span || 0) + ' m'
        + (build.quality.improved ? ' · rebuilt once to fix it' : '');
      card.appendChild(check);
      for (const issue of (build.quality.issues || []).slice(0, 3)) {
        const row = document.createElement('div');
        row.className = 'mbx-ai-warn';
        row.textContent = '• ' + issue;
        card.appendChild(row);
      }
    }
    if (build.warnings && build.warnings.length) {
      for (const warning of build.warnings.slice(0, 5)) {
        const w = document.createElement('div');
        w.className = 'mbx-ai-warn';
        w.textContent = '• ' + warning;
        card.appendChild(w);
      }
    }
    const tree = document.createElement('div');
    tree.className = 'mbx-ai-tree';
    tree.textContent = treeText(build.root);
    card.appendChild(tree);

    const actions = document.createElement('div');
    actions.className = 'mbx-ai-actions';
    const importBtn = document.createElement('button');
    importBtn.type = 'button';
    importBtn.className = 'mbx-ai-primary';
    importBtn.textContent = 'Import into editor';
    importBtn.addEventListener('click', () => importInvention(build));
    const copyBtn = document.createElement('button');
    copyBtn.type = 'button';
    copyBtn.textContent = 'Copy JSON';
    copyBtn.addEventListener('click', () => copyBuild(build));
    const downloadBtn = document.createElement('button');
    downloadBtn.type = 'button';
    downloadBtn.textContent = 'Download';
    downloadBtn.addEventListener('click', () => downloadJson(build));
    actions.appendChild(importBtn);
    actions.appendChild(copyBtn);
    actions.appendChild(downloadBtn);
    card.appendChild(actions);
    wrap.appendChild(card);
  }

  function countNodes(node) {
    if (!node) return 0;
    let count = 1;
    for (const child of node.stuckChildren || []) count += countNodes(child.item || child);
    return count;
  }

  function treeText(node, depth, lines) {
    const out = lines || [];
    const d = depth || 0;
    out.push('  '.repeat(d) + (node.itemID || '?'));
    if (d < 3) {
      for (const child of (node.stuckChildren || []).slice(0, 40)) {
        treeText(child.item || child, d + 1, out);
      }
    }
    return out.slice(0, 60).join('\n');
  }

  function copyBuild(build) {
    const text = JSON.stringify(build.root, null, 2);
    const done = () => setStatus($('#mbx-ai-build-status', state.panel), 'JSON copied.', 'good');
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(text).then(done).catch(() => {
        setStatus($('#mbx-ai-build-status', state.panel), 'Copy failed; use Download.', 'error');
      });
    } else {
      setStatus($('#mbx-ai-build-status', state.panel), 'Clipboard unavailable; use Download.', 'error');
    }
  }

  function downloadJson(build) {
    const blob = new Blob([JSON.stringify(build.root, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = (build.name || 'ai-build').replace(/[^a-z0-9_-]+/gi, '-').slice(0, 40) + '.json';
    a.click();
    setTimeout(() => URL.revokeObjectURL(url), 4000);
  }

  function importInvention(build) {
    const status = $('#mbx-ai-build-status', state.panel);
    const root = build && build.root ? build.root : build;
    if (!root || !root.itemID) {
      setStatus(status, 'There is no build to import.', 'error');
      return;
    }
    const byId = document.getElementById('loadFileInput');
    const input = byId || $$('input[type="file"]').find((node) => {
      const label = node.closest('label');
      return label && /replace active/i.test(label.textContent || '');
    });
    if (!input) {
      setStatus(status, 'Could not find the editor import input. Use Download instead.', 'error');
      return;
    }
    const file = new File([JSON.stringify(root, null, 2)], 'mbx-ai-build.json', { type: 'application/json' });
    const transfer = new DataTransfer();
    transfer.items.add(file);
    input.files = transfer.files;
    input.dispatchEvent(new Event('change', { bubbles: true }));
    setStatus(status, 'Imported into the active editor tab.', 'good');
  }

  /* ------------------------------------------------------------------ */
  /* Image                                                               */
  /* ------------------------------------------------------------------ */

  function currentImageModel() {
    if (!state.panel) return state.aiSettings.imageModel;
    const select = $('#mbx-ai-imgmodel', state.panel);
    return (select && select.value) || state.aiSettings.imageModel || CORE.IMAGE_MODELS[0].id;
  }

  async function generateImage() {
    if (!state.panel) return;
    const button = $('#mbx-ai-img-go', state.panel);
    const status = $('#mbx-ai-img-status', state.panel);
    const prompt = ($('#mbx-ai-imgprompt', state.panel).value || '').trim();
    if (!prompt) {
      setStatus(status, 'Describe the image first.', 'error');
      return;
    }
    if (!state.keyConfigured) {
      setStatus(status, 'Add an NVIDIA API key in settings first.', 'error');
      return;
    }
    const size = $('#mbx-ai-imgsize', state.panel).value;
    setStatus(status, 'Generating artwork…');
    busy(button, true, 'Painting…');
    try {
      const response = await send('mbx-ai-image', {
        payload: { prompt: prompt, size: size, model: currentImageModel() },
      });
      if (!response || !response.ok) {
        setStatus(status, (response && response.error) || 'Image generation failed.', 'error');
        return;
      }
      state.lastImage = response.dataUrl;
      setStatus(status, 'Image ready.', 'good');
      renderImageResult(response.dataUrl, prompt, 'img');
    } finally {
      busy(button, false);
    }
  }

  function renderImageResult(dataUrl, prompt, target) {
    const wrap = target === 'edit' ? $('#mbx-ai-edit-result', state.panel) : $('#mbx-ai-img-result', state.panel);
    if (!wrap) return;
    wrap.innerHTML = '';
    const img = document.createElement('img');
    img.className = 'mbx-ai-result';
    img.src = dataUrl;
    img.alt = prompt || 'Generated image';
    wrap.appendChild(img);
    const actions = document.createElement('div');
    actions.className = 'mbx-ai-actions';
    const download = document.createElement('button');
    download.type = 'button';
    download.textContent = 'Download PNG';
    download.addEventListener('click', () => downloadDataUrl(dataUrl, 'mikeybox-ai-art'));
    const attach = document.createElement('button');
    attach.type = 'button';
    attach.className = 'mbx-ai-primary';
    attach.textContent = 'Attach to item';
    attach.addEventListener('click', () => attachImage(dataUrl, prompt));
    actions.appendChild(download);
    actions.appendChild(attach);
    wrap.appendChild(actions);
  }

  async function attachLastImage() {
    if (!state.lastImage) {
      setStatus($('#mbx-ai-art-status', state.panel), 'Generate an image or use Image → 2D first.', 'error');
      return;
    }
    const select = $('#mbx-ai-itemtarget', state.panel);
    await attachImage(state.lastImage, $('#mbx-ai-imgprompt', state.panel).value, select && select.value);
  }

  async function attachImage(dataUrl, prompt, explicitTarget) {
    if (!state.panel) return;
    const status = $('#mbx-ai-art-status', state.panel);
    const select = $('#mbx-ai-itemtarget', state.panel);
    const target = explicitTarget || (select && select.value);
    if (!target) {
      setStatus(status, 'Choose an item first (open the Image tab and pick one).', 'error');
      return;
    }
    setStatus(status, 'Compressing artwork…');
    let small = dataUrl;
    try {
      small = await compressImage(dataUrl, 512);
    } catch (err) {
      small = dataUrl;
    }
    state.art[target] = { dataUrl: small, prompt: String(prompt || '').slice(0, 200), createdAt: Date.now() };
    const entries = Object.entries(state.art).sort((a, b) => (b[1].createdAt || 0) - (a[1].createdAt || 0));
    if (entries.length > MAX_ART) {
      state.art = Object.fromEntries(entries.slice(0, MAX_ART));
    }
    await localSet({ [ART_KEY]: state.art });
    applyCatalogDecorations();
    renderGallery();
    setStatus(status, 'Attached AI art to ' + target + '.', 'good');
  }

  function compressImage(dataUrl, maxSize) {
    return new Promise((resolve, reject) => {
      const img = new Image();
      img.onload = () => {
        try {
          const scale = Math.min(1, maxSize / Math.max(img.width, img.height));
          const canvas = document.createElement('canvas');
          canvas.width = Math.max(1, Math.round(img.width * scale));
          canvas.height = Math.max(1, Math.round(img.height * scale));
          const context = canvas.getContext('2d');
          context.drawImage(img, 0, 0, canvas.width, canvas.height);
          resolve(canvas.toDataURL('image/webp', 0.85));
        } catch (err) {
          reject(err);
        }
      };
      img.onerror = reject;
      img.src = dataUrl;
    });
  }

  function renderGallery() {
    if (!state.panel) return;
    const wrap = $('#mbx-ai-gallery', state.panel);
    if (!wrap) return;
    wrap.innerHTML = '';
    const entries = Object.entries(state.art).sort((a, b) => (b[1].createdAt || 0) - (a[1].createdAt || 0)).slice(0, 8);
    for (const [id, art] of entries) {
      const figure = document.createElement('figure');
      const img = document.createElement('img');
      img.src = art.dataUrl;
      img.alt = 'AI art for ' + id;
      img.title = art.prompt || id;
      const del = document.createElement('button');
      del.type = 'button';
      del.textContent = '×';
      del.title = 'Remove art for ' + id;
      del.addEventListener('click', async () => {
        delete state.art[id];
        await localSet({ [ART_KEY]: state.art });
        applyCatalogDecorations();
        renderGallery();
      });
      const caption = document.createElement('figcaption');
      caption.textContent = id.replace(/^item_/, '');
      figure.appendChild(img);
      figure.appendChild(del);
      figure.appendChild(caption);
      wrap.appendChild(figure);
    }
  }

  function readUpload(event) {
    const file = event.target.files && event.target.files[0];
    if (!file) {
      state.uploadImage = '';
      return;
    }
    if (file.size > 9 * 1024 * 1024) {
      setStatus($('#mbx-ai-edit-status', state.panel), 'Choose an image under 9 MB.', 'error');
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      state.uploadImage = String(reader.result || '');
      const wrap = $('#mbx-ai-edit-result', state.panel);
      if (wrap) {
        wrap.innerHTML = '';
        const img = document.createElement('img');
        img.className = 'mbx-ai-result';
        img.src = state.uploadImage;
        img.alt = 'Uploaded image';
        wrap.appendChild(img);
      }
      setStatus($('#mbx-ai-edit-status', state.panel), 'Image loaded. Choose Image → 2D or Image → 3D.');
    };
    reader.readAsDataURL(file);
  }

  async function editImage() {
    if (!state.panel) return;
    const status = $('#mbx-ai-edit-status', state.panel);
    if (!state.uploadImage) {
      setStatus(status, 'Choose an image first.', 'error');
      return;
    }
    const prompt = ($('#mbx-ai-imgprompt', state.panel).value || '').trim() || 'Repaint this object as a clean Animal Company item icon';
    const button = $('#mbx-ai-edit-go', state.panel);
    setStatus(status, 'Sending the image to the edit model…');
    busy(button, true, 'Editing…');
    try {
      const response = await send('mbx-ai-image-edit', {
        payload: { prompt: prompt, image: state.uploadImage, model: state.aiSettings.editModel },
      }, 190000);
      if (!response || !response.ok) {
        setStatus(status, (response && (response.error + (response.hint ? '\n' + response.hint : ''))) || 'Edit failed.', 'error');
        return;
      }
      state.lastImage = response.dataUrl;
      setStatus(status, 'Edited image ready.', 'good');
      renderImageResult(response.dataUrl, prompt, 'edit');
    } finally {
      busy(button, false);
    }
  }

  async function generate3d(fromImage) {
    if (!state.panel) return;
    const status = $('#mbx-ai-edit-status', state.panel);
    if (fromImage && !state.uploadImage) {
      setStatus(status, 'Choose an image first.', 'error');
      return;
    }
    const prompt = ($('#mbx-ai-imgprompt', state.panel).value || '').trim();
    if (!fromImage && !prompt) {
      setStatus(status, 'Describe the model first, or upload an image.', 'error');
      return;
    }
    const button = fromImage ? $('#mbx-ai-3d-img', state.panel) : $('#mbx-ai-3d-text', state.panel);
    setStatus(status, 'Building a 3D model…');
    busy(button, true, 'Building…');
    try {
      const response = await send('mbx-ai-3d', {
        payload: { image: fromImage ? state.uploadImage : '', prompt: prompt, model: state.aiSettings.model3d },
      }, 310000);
      if (!response || !response.ok) {
        setStatus(status, (response && (response.error + (response.hint ? '\n' + response.hint : ''))) || '3D generation failed.', 'error');
        return;
      }
      const bytes = Uint8Array.from(atob(response.base64), (c) => c.charCodeAt(0));
      const blob = new Blob([bytes], { type: response.mime || 'model/gltf-binary' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'mikeybox-ai-model.glb';
      a.click();
      setTimeout(() => URL.revokeObjectURL(url), 5000);
      setStatus(status, '3D model downloaded as GLB.', 'good');
    } finally {
      busy(button, false);
    }
  }

  function downloadDataUrl(dataUrl, baseName) {
    const a = document.createElement('a');
    a.href = dataUrl;
    const match = /^data:image\/([a-z0-9+.-]+)/i.exec(dataUrl);
    a.download = baseName + '.' + (match ? (match[1] === 'jpeg' ? 'jpg' : match[1]) : 'png');
    a.click();
  }

  /* ------------------------------------------------------------------ */
  /* Public handle (used by the quick panel and tests)                   */
  /* ------------------------------------------------------------------ */

  window.MBXAI = {
    open: openPanel,
    close: closePanel,
    toggle: togglePanel,
    selectView: selectView,
    setPrompt: setPrompt,
    generateBuild: generateBuild,
    importInvention: importInvention,
    attachImage: attachImage,
    state: state,
    refreshData: loadSiteData,
  };

  boot();
})();
