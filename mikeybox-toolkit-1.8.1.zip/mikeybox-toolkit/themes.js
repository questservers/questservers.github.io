/* Mikeybox Toolkit — shared theme data.
   Loaded before content.js on the site and by popup.html in the extension UI. */
(function () {
  'use strict';

  const THEMES = [
    {
      id: 'mikeybox',
      name: 'Mikeybox',
      group: 'Default',
      colors: {
        bg: '#101114', panel: '#181a1f', panel2: '#202329', line: '#333842',
        text: '#eceff3', muted: '#a5acb8', accent: '#6fc2ff', good: '#86df9d', bad: '#ff8d8d',
      },
    },
    {
      id: 'midnight',
      name: 'Midnight',
      group: 'Dark',
      colors: {
        bg: '#0a1020', panel: '#111a2e', panel2: '#18243c', line: '#2b3a58',
        text: '#e8efff', muted: '#94a6c6', accent: '#5aa9ff', good: '#6fe3b0', bad: '#ff8a9a',
      },
    },
    {
      id: 'amoled',
      name: 'AMOLED',
      group: 'Dark',
      colors: {
        bg: '#000000', panel: '#08080a', panel2: '#101014', line: '#26262e',
        text: '#f4f4f7', muted: '#9a9aa8', accent: '#9d7bff', good: '#4ade80', bad: '#ff6b6b',
      },
    },
    {
      id: 'slate',
      name: 'Slate',
      group: 'Dark',
      colors: {
        bg: '#0e1620', panel: '#15202b', panel2: '#1c2b38', line: '#2e4354',
        text: '#e6eff6', muted: '#9cb2c2', accent: '#4cc2dd', good: '#79d6a4', bad: '#ff9292',
      },
    },
    {
      id: 'nord',
      name: 'Nord',
      group: 'Dark',
      colors: {
        bg: '#2e3440', panel: '#3b4252', panel2: '#434c5e', line: '#4c566a',
        text: '#eceff4', muted: '#b3bccc', accent: '#88c0d0', good: '#a3be8c', bad: '#bf616a',
      },
    },
    {
      id: 'tokyonight',
      name: 'Tokyo Night',
      group: 'Dark',
      colors: {
        bg: '#16161e', panel: '#1a1b26', panel2: '#24283b', line: '#303650',
        text: '#c0caf5', muted: '#8b96bd', accent: '#7aa2f7', good: '#9ece6a', bad: '#f7768e',
      },
    },
    {
      id: 'dracula',
      name: 'Dracula',
      group: 'Dark',
      colors: {
        bg: '#1e1f29', panel: '#282a36', panel2: '#323444', line: '#44475a',
        text: '#f8f8f2', muted: '#b0b7d0', accent: '#bd93f9', good: '#50fa7b', bad: '#ff5555',
      },
    },
    {
      id: 'gruvbox',
      name: 'Gruvbox',
      group: 'Dark',
      colors: {
        bg: '#1b1e1f', panel: '#282828', panel2: '#32302f', line: '#504945',
        text: '#ebdbb2', muted: '#a89984', accent: '#fabd2f', good: '#b8bb26', bad: '#fb4934',
      },
    },
    {
      id: 'catmocha',
      name: 'Catppuccin',
      group: 'Dark',
      colors: {
        bg: '#11111b', panel: '#181825', panel2: '#1e1e2e', line: '#313244',
        text: '#cdd6f4', muted: '#a6adc8', accent: '#cba6f7', good: '#a6e3a1', bad: '#f38ba8',
      },
    },
    {
      id: 'rosepine',
      name: 'Rosé Pine',
      group: 'Dark',
      colors: {
        bg: '#191724', panel: '#1f1d2e', panel2: '#26233a', line: '#403d52',
        text: '#e0def4', muted: '#9b96b8', accent: '#c4a7e7', good: '#9ccfd8', bad: '#eb6f92',
      },
    },
    {
      id: 'carbon',
      name: 'Carbon',
      group: 'Dark',
      colors: {
        bg: '#0d0f12', panel: '#15181d', panel2: '#1d2128', line: '#2f3540',
        text: '#e9edf2', muted: '#98a3b2', accent: '#ffb347', good: '#7bd88f', bad: '#ff7b72',
      },
    },
    {
      id: 'cyberpunk',
      name: 'Cyberpunk',
      group: 'Neon',
      colors: {
        bg: '#0b0714', panel: '#150d25', panel2: '#1e1335', line: '#3d2566',
        text: '#f2eaff', muted: '#a894cf', accent: '#ff2e97', good: '#00ffc8', bad: '#ff5c5c',
      },
    },
    {
      id: 'synthwave',
      name: 'Synthwave',
      group: 'Neon',
      colors: {
        bg: '#140b26', panel: '#1c1036', panel2: '#281647', line: '#4a2a75',
        text: '#ffe9ff', muted: '#b394d9', accent: '#ff7edb', good: '#72f1b8', bad: '#fe4450',
      },
    },
    {
      id: 'toxic',
      name: 'Toxic Lime',
      group: 'Neon',
      colors: {
        bg: '#0a0f0a', panel: '#101810', panel2: '#162216', line: '#2b3f2b',
        text: '#eaffea', muted: '#94b494', accent: '#b6ff3c', good: '#58ffa1', bad: '#ff6b6b',
      },
    },
    {
      id: 'ember',
      name: 'Ember',
      group: 'Neon',
      colors: {
        bg: '#130c0a', panel: '#1c1310', panel2: '#261a16', line: '#45291f',
        text: '#ffece4', muted: '#c0a094', accent: '#ff7a45', good: '#8ce99a', bad: '#ff6b6b',
      },
    },
    {
      id: 'daybreak',
      name: 'Daybreak',
      group: 'Light',
      colors: {
        bg: '#eef1f6', panel: '#ffffff', panel2: '#f4f6fa', line: '#ccd4e0',
        text: '#16202b', muted: '#56677a', accent: '#1d6fd6', good: '#1c7a45', bad: '#c02f2f',
      },
    },
    {
      id: 'latte',
      name: 'Catppuccin Latte',
      group: 'Light',
      colors: {
        bg: '#eff1f5', panel: '#ffffff', panel2: '#e6e9ef', line: '#ccd0da',
        text: '#4c4f69', muted: '#64677d', accent: '#8839ef', good: '#2f8c1f', bad: '#c8102f',
      },
    },
    {
      id: 'solarized',
      name: 'Solarized Light',
      group: 'Light',
      colors: {
        bg: '#fdf6e3', panel: '#fffbf0', panel2: '#f5eeda', line: '#d9cfb3',
        text: '#4a5d63', muted: '#6d7d80', accent: '#1f6fb2', good: '#5d7a00', bad: '#c02a25',
      },
    },
    {
      id: 'paper',
      name: 'Paper',
      group: 'Light',
      colors: {
        bg: '#f4efe4', panel: '#fffdf7', panel2: '#eee7d8', line: '#d8cdb6',
        text: '#2f2a22', muted: '#6a5f4e', accent: '#a84c07', good: '#3c7a3f', bad: '#b3261e',
      },
    },
    {
      id: 'forest',
      name: 'Forest',
      group: 'Nature',
      colors: {
        bg: '#0b1410', panel: '#11201a', panel2: '#172b22', line: '#294737',
        text: '#e8f7ee', muted: '#9bbba9', accent: '#5cd98a', good: '#a3e34f', bad: '#ff7b72',
      },
    },
    {
      id: 'ocean',
      name: 'Ocean',
      group: 'Nature',
      colors: {
        bg: '#061219', panel: '#0b1e28', panel2: '#102a36', line: '#1e4655',
        text: '#e4f5fc', muted: '#8fb6c6', accent: '#35c7f0', good: '#5ee0b0', bad: '#ff7b8a',
      },
    },
    {
      id: 'candy',
      name: 'Candy',
      group: 'Nature',
      colors: {
        bg: '#1a1024', panel: '#241530', panel2: '#2f1c3e', line: '#4a2c5e',
        text: '#ffe9ff', muted: '#c3a4d8', accent: '#ff9bd2', good: '#9dffb3', bad: '#ff6b8b',
      },
    },
    {
      id: 'matcha',
      name: 'Matcha',
      group: 'Nature',
      colors: {
        bg: '#12150f', panel: '#1a1f16', panel2: '#232b1d', line: '#38452c',
        text: '#f0f5e6', muted: '#a9b89a', accent: '#a8d96c', good: '#c3e88d', bad: '#ff8a80',
      },
    },
  ];

  const CUSTOM_ID = 'custom';

  const DEFAULT_COLORS = {
    bg: '#101114', panel: '#181a1f', panel2: '#202329', line: '#333842',
    text: '#eceff3', muted: '#a5acb8', accent: '#bd93f9', good: '#86df9d', bad: '#ff8d8d',
  };

  const COLOR_FIELDS = [
    { key: 'bg', label: 'Background', hint: 'Page and viewport backdrop' },
    { key: 'panel', label: 'Panels', hint: 'Sidebars and toolbars' },
    { key: 'panel2', label: 'Controls', hint: 'Buttons and raised surfaces' },
    { key: 'line', label: 'Borders', hint: 'Dividers and outlines' },
    { key: 'text', label: 'Text', hint: 'Primary labels' },
    { key: 'muted', label: 'Muted text', hint: 'Hints and secondary info' },
    { key: 'accent', label: 'Accent', hint: 'Selection, focus, links' },
    { key: 'good', label: 'Success', hint: 'Valid and positive states' },
    { key: 'bad', label: 'Danger', hint: 'Errors and destructive actions' },
  ];

  const FONTS = [
    { id: 'segoe', label: 'Segoe UI (site default)', stack: '"Segoe UI", Arial, sans-serif' },
    { id: 'system', label: 'System UI', stack: 'system-ui, -apple-system, "Segoe UI", Roboto, Arial, sans-serif' },
    { id: 'verdana', label: 'Verdana', stack: 'Verdana, Geneva, sans-serif' },
    { id: 'trebuchet', label: 'Trebuchet MS', stack: '"Trebuchet MS", "Segoe UI", sans-serif' },
    { id: 'georgia', label: 'Georgia (serif)', stack: 'Georgia, "Times New Roman", serif' },
    { id: 'mono', label: 'Monospace', stack: '"Cascadia Mono", Consolas, "Courier New", monospace' },
  ];

  const WALLPAPERS = [
    { id: 'none', label: 'None (flat colour)' },
    { id: 'dots', label: 'Dots' },
    { id: 'grid', label: 'Grid' },
    { id: 'mesh', label: 'Accent mesh' },
    { id: 'aurora', label: 'Aurora' },
    { id: 'custom', label: 'Custom image URL' },
  ];

  const DEFAULT_SETTINGS = {
    enabled: true,
    themeId: 'mikeybox',
    accentOverride: '',
    customColors: Object.assign({}, DEFAULT_COLORS),
    radius: 6,
    textSize: 13,
    font: 'segoe',
    panelOpacity: 100,
    blur: 0,
    glow: false,
    reduceMotion: false,
    thumbSize: 88,
    wallpaper: 'none',
    wallpaperUrl: '',
    compact: false,
    hideTip: false,
    hidePromo: false,
    hideBrand: false,
    hideStatus: false,
    hideFilm: false,
    hideValidation: false,
    hideOutputJson: false,
    hidePetNote: false,
    hideHintNote: false,
    hideSortRow: false,
    hideViewToggle: false,
    hideItemInfo: false,
    hideScrollbars: false,
    hideToolbar: false,
    aiButton: true,
    fps: false,
    markBanned: true,
    hideBanned: false,
    showAiArt: true,
    autoArrange: true,
    hideSiteBanner: false,
    revamp: false,
    streamer: false,
  };

  /* Build signature. It is stamped on every node the toolkit creates and in the
     AI Studio footer, so a re-uploaded copy can be traced back to this build. */
  const SIGNATURE = 'MBX-TKL/2 · PRIME-6F3A9C';

  /* Streamer mode hides who is on screen, not what the editor is doing: names,
     the Prime recovery session and the build signature get masked, item names
     and prices never do. */
  const STREAMER_NAME = 'Player';
  const STREAMER_MASK = '••••••';

  function maskSignature(signature, on) {
    if (!on) return signature || '';
    return 'MBX-TKL/2 · PRIME-' + STREAMER_MASK;
  }

  function maskName(name, on) {
    if (!on) return name || '';
    return name ? STREAMER_NAME : '';
  }

  function maskSecret(value, on) {
    if (!on) return value == null ? '' : String(value);
    return value ? STREAMER_MASK : '';
  }

  const JWT_RE = /\beyJ[A-Za-z0-9_-]{6,}\.[A-Za-z0-9_-]{6,}(?:\.[A-Za-z0-9_-]{4,})?/g;
  const ITEM_ID_RE = /item_[a-z0-9_]+/i;

  /* Masks a name inside short labels only - never in catalog rows or long
     paragraphs - so a player called Fox does not turn “Fox Hat” into “Player
     Hat”. Whole words, case-sensitive, like the page prints them. */
  function maskIdentityText(text, names, secrets) {
    let out = typeof text === 'string' ? text : '';
    for (const secret of secrets || []) {
      if (secret && secret.length >= 6) out = out.split(secret).join(STREAMER_MASK);
    }
    out = out.replace(JWT_RE, STREAMER_MASK);
    const trimmed = out.trim();
    if (!trimmed || trimmed.length > 120 || ITEM_ID_RE.test(trimmed)) return out;
    for (const name of names || []) {
      if (!name || name.length < 3) continue;
      const escaped = name.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      out = out.replace(new RegExp('(^|[^\\w-])' + escaped + '(?=$|[^\\w-])', 'g'),
        (match, prefix) => prefix + STREAMER_NAME);
    }
    return out;
  }

  const HEX_RE = /^#[0-9a-f]{6}$/i;

  function normalizeHex(value) {
    if (typeof value !== 'string') return '';
    let v = value.trim();
    if (!v) return '';
    if (v[0] !== '#') v = '#' + v;
    if (v.length === 4 && /^#[0-9a-f]{3}$/i.test(v)) {
      v = '#' + v[1] + v[1] + v[2] + v[2] + v[3] + v[3];
    }
    return HEX_RE.test(v) ? v.toLowerCase() : '';
  }

  function hexToRgb(hex) {
    const h = normalizeHex(hex);
    if (!h) return null;
    return {
      r: parseInt(h.slice(1, 3), 16),
      g: parseInt(h.slice(3, 5), 16),
      b: parseInt(h.slice(5, 7), 16),
    };
  }

  function isLight(hex) {
    const rgb = hexToRgb(hex);
    if (!rgb) return false;
    const lin = (c) => {
      const s = c / 255;
      return s <= 0.03928 ? s / 12.92 : Math.pow((s + 0.055) / 1.055, 2.4);
    };
    const luminance = 0.2126 * lin(rgb.r) + 0.7152 * lin(rgb.g) + 0.0722 * lin(rgb.b);
    return luminance > 0.45;
  }

  function resolveTheme(settings, customThemes) {
    const s = settings || DEFAULT_SETTINGS;
    if (s.themeId === CUSTOM_ID) {
      return {
        id: CUSTOM_ID,
        name: 'Custom',
        group: 'Custom',
        colors: Object.assign({}, DEFAULT_COLORS, s.customColors || {}),
      };
    }
    const list = THEMES.concat(customThemes || []);
    const theme = list.find((t) => t.id === s.themeId) || THEMES[0];
    const colors = Object.assign({}, theme.colors);
    if (s.accentOverride) colors.accent = s.accentOverride;
    return { id: theme.id, name: theme.name, group: theme.group, colors };
  }

  function themeOptions(customThemes) {
    return THEMES.concat(
      [{ id: CUSTOM_ID, name: 'Custom', group: 'Custom', colors: Object.assign({}, DEFAULT_COLORS) }],
      customThemes || []
    );
  }

  window.MBX = {
    THEMES,
    CUSTOM_ID,
    DEFAULT_COLORS,
    COLOR_FIELDS,
    FONTS,
    WALLPAPERS,
    DEFAULT_SETTINGS,
    normalizeHex,
    hexToRgb,
    isLight,
    resolveTheme,
    themeOptions,
    SIGNATURE,
    STREAMER_NAME,
    STREAMER_MASK,
    maskSignature,
    maskName,
    maskSecret,
    maskIdentityText,
  };
})();
