# Mikeybox Toolkit — AI Studio & Tweaks

A Chrome (Manifest V3) extension for the **Mikeybox Goop Editor** at
[prime.mikeybox.ai](https://prime.mikeybox.ai/) (and the Fabrication editor at
[fab.mikeybox.ai](https://fab.mikeybox.ai/)).

It adds a **Gemini- or NVIDIA-powered AI Studio** on top of the editor — generate whole
inventions from a prompt — plus a live **Data** panel built from the editor's own
endpoints, compact themes, and a growing set of layout/declutter tweaks. The AI
Studio is deliberately AI-only: everything else lives in the toolkit GUI (the
toolbar popup), and **Revamp** is a switch there. The old Image / 3D tab was
removed in 1.3; the cosmetic Fake client sandbox and the in-page quick panel
were removed in 1.6 and 1.7.

## Background

- **Animal Company** is a free multiplayer social VR survival/sandbox game by
  **Wooster Games** (Meta Quest, 2024; also on Steam). Players play as animals,
  loot maps, fight monsters, and stick items together with **Goop** to build
  inventions, vehicles and gadgets.
- **Mikeybox** is a community creative platform for Animal Company. **Prime** is
  its browser-based 3D *Goop Editor*: pick in-game items, parent them into an
  invention, preview it, then send the JSON to your account for in-game delivery
  through the Prime pad or the Mikeybox bot. The **Workshop** is where builds are
  shared.

## AI Studio

Open it with the floating **AI** button in the editor, with **Alt+Shift+A**, or
from the toolkit GUI footer. It has three tabs — **Build**, **Data** and
**Settings** — and all model calls run in the extension's service worker, so
the API key never touches the page.

The first time AI Studio opens in a browser session it shows a warning that the
AI is experimental and **will** make mistakes, with **Leave** (closes the studio)
and **Continue** (dismisses the warning for that session).

### Settings (key, models, endpoints)
The **Settings** tab (or the ⚙ button in the header) holds everything about the
AI connection — Gemini by default, NVIDIA if the key starts with `nvapi-`: the
API key with a **Key saved / No key** badge, **Save & scan models**, **Clear**,
the build / image / image-edit / 3D model pickers, **Scan for best** with the
ranked model list and last-scan time, and a collapsible **Advanced endpoints**
block for self-hosted NIMs. The key is stored in `chrome.storage.local` and only
ever read by the service worker.

### Gemini keys
Paste a Gemini key (`AIza…`, free at
<https://aistudio.google.com/apikey>) and **Save & scan models**. The worker
calls `generativelanguage.googleapis.com/v1beta/models/{model}:generateContent`
with the key in the `x-goog-api-key` header, maps the system prompt to
`systemInstruction`, and asks for `responseMimeType: application/json`. The
scan lists every model the key can see that supports `generateContent`, ranks
them, and **Auto** uses the best. Paste an `nvapi-…` key at any time and the
worker switches back to NVIDIA; the saved model list and pinned model are reset
because model IDs are provider-specific. Gemini keys do not cover the image or
3D endpoints — those stay NVIDIA-only.

### Build (prompt → invention)
1. Describe the invention and set a maximum part count.
2. The request is matched against the editor's real part palette and turned into
   a **design brief**: aircraft, ground vehicle, watercraft, drone, wearable
   suit, robot, structure or weapon. Each brief carries the silhouette, the part count it
   needs, mirrored-pair rules and the actual item IDs for each job (frame,
   wings, engines, wheels, seat, lights) — pulled from the site's own
   `items.json` catalog and dropped again if the live catalog no longer allows
   them. Parts named in the prompt are promoted to the top of the shortlist.
3. The worker sends that brief, the shortlist and a compact worked example in
   the exact output shape to your selected model, then validates every
   item ID against the live catalog, drops **banned** and unknown IDs, snaps every
   rotation to the 90° grid and fills in any missing position.
4. A deterministic **shape check** scores the result (part count vs the brief,
   mirrored pairs, wingspan vs fuselage, structural parts, repetition, cramped
   spacing). Under 70/100 it sends the issues back for one rebuild and keeps
   whichever version scores higher. The card shows the score, pair count, span
   and what was wrong.
5. Review the name, part/goop counts and any warnings, then **Import into
   editor** (uses the editor's own `Load file (replace active)` input), copy the
   JSON, or download it.

**Orientation.** A part's `rot` is a quaternion `[x,y,z,w]`, and a build only
ever needs quarter turns, so the prompt lists the exact table — identity, ±90°
about each axis, the three 180° turns — and the mirror rule: mirroring a part
across x flips `pos.x` and turns `rot` into `[x,-y,-z,w]`. The same rot on both
sides of a pair flips one mesh, which is what used to make wheels and wings look
twisted. On the way in, `normalizeInvention()` snaps every value to that grid
(the 24 cube rotations) and then repairs two decidable mistakes: a mirrored pair
that shares one rot gets the mirrored rot, and a gear wheel lying coin-flat at
the side of the build gets its axle back on x.

The local axes are measured from the editor's own exported models
(`exported_item_models/*.glb`), not guessed: a gear is `0.21 × 0.67 × 0.67`, so
**its axle is local x and identity is already the upright wheel** — earlier
builds said the opposite and told the model to roll every wheel 90° about z,
which laid them all flat like coins. Planks, beams and rods run along y; plates,
pallets and fans are squares facing z. That fixes the vocabulary for decks
(plate face up: `[-0.7071,0,0,0.7071]`), skirts (plate facing +x:
`[0,0.7071,0,0.7071]`), barrels (rod pointing −z: `[-0.7071,0,0,0.7071]`) and
rotors (fan facing up: the same `x−90`), and it rules out one impossible pose: a
plank cannot lie flat across x with quarter turns, so decks across x use square
plates.

**Wearable builds.** Anything the player puts on — suit, cosplay, armour, an egg
suit — is planned against its own brief and roots on `item_backpack_small_base`,
the pack the game snaps to the player's back. Children are measured from that
pack, so the brief and the shape check both enforce a body envelope: `|x| ≤ 0.42`,
`|z| ≤ 0.3`, `y` from `-0.5` to `0.75`. The brief builds the shell from a few
scaled `item_football` goop blobs, hangs mirrored `robot_arm_left`/`_right` at
`x ±0.3` and puts the head at `y ≈ 0.62`. If the model still returns a tower rooted
on a beam, normalization swaps the root to the pack and drops any `grabPos`
offset, and the shape check calls out a build that grows over the player's head
or hangs out past their arms — the 14-part "moon mech" that stood beside the
player is now scored as a wearable instead of passing as 100/100.

The model is **Auto** by default: every build ranks the models the key can see
and uses the highest-scoring one that supports structured JSON output. If that
model stalls or has disappeared, the worker retries the next ranked model once
and reports the switch, so one slow model no longer fails the build. Pick a
specific model on the popup's **AI** tab to pin it; **Scan for best** only
replaces a manual pick. If the account cannot list models, the worker falls back
to a curated, ranked shortlist instead of failing.

### You on Prime

The Data tab reads the editor's own browser state (no API key involved):

| Source | Shows |
| --- | --- |
| `mikeybox_recent_player_names` | **In-game username** — the newest entry, plus the other recent ones |
| `mikeybox_platform` | Quest or SteamVR delivery |
| `mikeybox_editor_layout_v1`, `mikeybox_editor_tool_tab_v1`, `mikeybox_hand_tracking_profile` | Editor layout, open tool tab, hand-tracking profile |
| `sessionStorage.mikeybox_goop_recovery_session_v1` | Short recovery session id |

**Copy dossier** puts all of it (plus site mode, game build and pad population)
into one JSON object. Token and cookie values are never read, stored or copied.

### Data
Read from the same network calls the editor makes:

| Endpoint | Used for |
| --- | --- |
| `/items.json` | Catalog (786 items), categories, `banned` list |
| `/api/build-security` | Build security level per platform, blacklist/allowlist |
| `/goop_build_policy.mjs` | Max descendants (512), container contents (30), nesting depth (4), copies per build |
| `/api/site-status` | Site mode and the current banner |
| `/api/versions` | Game version, site build, Prime pad player count |

Banned items get a red **BANNED** badge in the catalog, can be hidden entirely,
and the chips in the Data tab filter the catalog for that ID.

## Toolkit GUI (toolbar popup)

The extension button opens the toolkit GUI: **Themes**, **Tweaks**, **Custom**
and **About**. AI Studio stays in the editor and owns its own settings, so
everything else about the page is configured from here, and changes apply to
open editor tabs immediately.

**Tweaks** holds the layout sliders (opacity, radius, text size, thumbnails,
font), compact spacing, glow, reduce motion, the catalog toggles, **Streamer
mode**, the wallpaper, the full declutter list, **Revamp** and the FPS HUD. It
also carries **Editor actions** — Send to game, Copy username and Copy dossier —
which are relayed to the active Prime/Fab tab, so the page keeps its own buttons
and storage.

**Themes** has the built-in palettes with group filters and the accent override;
**Custom** builds and stores your own palette and custom CSS; **About** explains
the site and the game. In the editor, <kbd>Alt</kbd>+<kbd>Shift</kbd>+<kbd>M</kbd>
opens this GUI, <kbd>Alt</kbd>+<kbd>Shift</kbd>+<kbd>D</kbd> copies the dossier
and <kbd>Alt</kbd>+<kbd>Shift</kbd>+<kbd>S</kbd> toggles Streamer mode.

## Site tools

### Revamp shell

One switch in **Tweaks** replaces the editor shell. The site header, brand block,
guide tip and sidebar tabs are hidden and a toolkit bar takes their place, with
Items / Workspace / Wearer switching the site's real panels, the live document
name, Save, Download, an AI Studio launcher and a **Classic** button that turns
it all off again.

The layout becomes three columns that fill the window (catalog · 3D viewport ·
inspector) with the catalog reflowing its thumbnails to the narrower rail. The
functional nodes — `#viewport`, `#itemList`, `#inspectorPanel`, the toolbars —
stay exactly where the editor expects them, because deleting them would take the
3D scene and its event wiring with them. Themes, compact mode and the other
tweaks still apply on top.

## Streamer mode (Alt+Shift+S)

For recording or screen sharing: it hides who is on screen, not what the editor
is doing.

- Your in-game name — the `mikeybox_recent_player_names` entry — becomes
  **Player** in page text and the AI Studio profile card.
- The **Prime recovery session**, any visible JWT-shaped value and the build
  signature (`MBX-TKL/2 · PRIME-…`) become dots, including the `data-mbx-sig`
  attribute and the studio footer.
- **Copy username** copies `Player`, and **Copy dossier** keeps its shape with
  the name, recent names and session blanked (`"streamerHidden": true`).
- A red **STREAMER** pill sits next to the Prime badge so it is obvious the
  masking is live.

Item names, categories, prices and catalog data are never masked — the point is
to hide your identity, not to make the editor useless on stream. Page text is
rewritten in place, only for the player's own name and session values, and the
originals go back the moment you switch it off. Toggle it under **Tweaks** in
the toolkit GUI, in AI Studio's Data tab, or with the hotkey.

## Themes

- **23 built-in themes**: Mikeybox (original), Midnight, AMOLED, Slate, Nord,
  Tokyo Night, Dracula, Gruvbox, Catppuccin Mocha, Rosé Pine, Carbon, Cyberpunk,
  Synthwave, Toxic Lime, Ember, Daybreak, Catppuccin Latte, Solarized Light,
  Paper, Forest, Ocean, Candy, Matcha.
- **Accent override**, a **9-slot custom palette**, save/delete, portable JSON
  export/import.
- Themes override the editor's nine CSS variables *and* its hard-coded surfaces
  (inputs, catalog rows, tabs, dialogs, badges, status bar, scrollbars).
- The toolkit GUI opens on **Themes** and uses a compact 4-column theme grid.

## Tweaks

- Panel opacity (55–100%), backdrop blur, corner radius, text size, thumbnail
  width, six fonts, compact spacing, accent glow, reduce motion.
- Backgrounds: dots, grid, accent mesh, aurora, custom image URL.
- Declutter: guide tip, promo/NEW link, brand header, status bar, pet delivery
  note, “Choose an item” hint, sort/category row, Names/Thumbnails toggle, item
  info dots, scrollbars, scene toolbar, Film gear, Validation, output JSON.
- Extras: AI Studio button (Alt+Shift+A), dossier hotkey (Alt+Shift+D),
  streamer mode (Alt+Shift+S), FPS HUD, Revamp shell, hide the site's own
  banner, 6,000-character custom CSS. When Revamp is on, the floating AI button
  hides because the revamp bar carries AI Studio.

## Install (unpacked)

1. Open `chrome://extensions` (or `edge://extensions`, `brave://extensions`).
2. Turn on **Developer mode**.
3. Click **Load unpacked** and select this folder (the one with `manifest.json` at its root).
4. Open or reload <https://prime.mikeybox.ai/>.
5. Open the editor → **AI** button (or <kbd>Alt</kbd>+<kbd>Shift</kbd>+<kbd>A</kbd>)
   → **Settings** tab → paste a Gemini key (`AIza…`, free at
   <https://aistudio.google.com/apikey>) or an NVIDIA key (`nvapi-…`) →
   **Save & scan models**.

To update after editing files, hit the reload icon on the extension card, then
reload the editor tab.

### Requirements and permissions

- Chrome/Edge/Brave **111+**.
- `storage` permission; host access to `generativelanguage.googleapis.com`,
  `integrate.api.nvidia.com` and `ai.api.nvidia.com` for the AI calls; content
  scripts on the two Mikeybox editor origins.
- No analytics, no other network calls. The key stays in
  `chrome.storage.local` (not synced) and is only read by the service worker.

## Files

| File | Purpose |
| --- | --- |
| `manifest.json` | Manifest V3, AI scripts, Gemini/NVIDIA host permissions |
| `themes.js` | Theme palettes, helpers, default settings (shared) |
| `content.js` | Theme engine, tweak classes, FPS HUD, Revamp shell, streamer masking, page-action relay |
| `ai-core.js` | Pure AI helpers: model ranking, prompts, rotation snapping, JSON validation/normalisation |
| `ai.js` | In-page AI Studio: Build/Data/Settings tabs, catalog art, banned markers |
| `background.js` | Service worker: key storage, provider detection, every Gemini/NVIDIA request |
| `popup.html` / `popup.css` / `popup.js` | Toolkit GUI (toolbar popup and full-page options) |
| `icons/` | 16/32/48/128 px icons |

## How the thumbnail grid works

The editor hard-codes `.itemTile { height: 153px }` for an 82px preview. The
extension writes three explicit pixel variables — `--mbx-thumb-px`,
`--mbx-visual-h`, `--mbx-tile-h` — and sizes the grid from those. Earlier builds
sized the tile from a shared `--mbx-thumb`; a stale unit-less value (for example
`88` instead of `88px`) made the calc invalid and collapsed every tile to its
12px padding. The dedicated variables make the grid immune to a stale value.

## Notes & limitations

- Unofficial fan project. Not affiliated with Mikeybox, Wooster Games, Meta or
  NVIDIA.
- The WebGL viewport itself is not recoloured; canvas contents belong to the
  editor.
- AI builds are only as good as the model. The validator guarantees the JSON
  shape and allowed IDs, not that the invention is fun or balanced.
- `chrome.storage.sync` has a per-item quota, which is why custom CSS is capped
  at 6,000 characters.
- On Firefox, add `browser_specific_settings.gecko.id` and load it as a
  temporary add-on; Chrome is the primary target.
