/* Mikeybox Toolkit — content script.
   Applies themes, tweaks, Streamer masking and the Revamp shell to
   prime.mikeybox.ai / fab.mikeybox.ai, and relays the toolkit GUI's page
   actions (Send to game, Copy username, Copy dossier) from the popup. */
(function () {
  'use strict';
  if (window.__mbxToolkitLoaded) return;
  window.__mbxToolkitLoaded = true;

  const MBX = window.MBX;
  if (!MBX) return;

  const CACHE_KEY = 'mbx-toolkit-cache-v1';
  const STORE_KEYS = ['settings', 'customThemes', 'customCss'];
  const HIDE_CLASSES = {
    'mbx-compact': 'compact',
    'mbx-hide-tip': 'hideTip',
    'mbx-hide-promo': 'hidePromo',
    'mbx-hide-brand': 'hideBrand',
    'mbx-hide-status': 'hideStatus',
    'mbx-hide-film': 'hideFilm',
    'mbx-hide-validation': 'hideValidation',
    'mbx-hide-json': 'hideOutputJson',
    'mbx-hide-pet-note': 'hidePetNote',
    'mbx-hide-hint-note': 'hideHintNote',
    'mbx-hide-sort-row': 'hideSortRow',
    'mbx-hide-view-toggle': 'hideViewToggle',
    'mbx-hide-item-info': 'hideItemInfo',
    'mbx-hide-scrollbars': 'hideScrollbars',
    'mbx-hide-toolbar': 'hideToolbar',
    'mbx-hide-site-banner': 'hideSiteBanner',
    'mbx-glow': 'glow',
    'mbx-reduce-motion': 'reduceMotion',
    'mbx-streamer': 'streamer',
  };
  const WALL_CLASSES = ['mbx-wall-dots', 'mbx-wall-grid', 'mbx-wall-mesh', 'mbx-wall-aurora', 'mbx-wall-custom'];

  const state = {
    settings: Object.assign({}, MBX.DEFAULT_SETTINGS),
    customThemes: [],
    customCss: '',
  };

  let styleEl = null;
  let customCssEl = null;
  let fpsEl = null;
  let fpsRaf = 0;
  let fpsFrames = 0;
  let fpsLast = 0;
  let revampBar = null;
  let revampTimer = 0;
  let revampInput = null;
  let revampDocHandler = null;

  const clamp = (value, min, max, fallback) => {
    const n = Number(value);
    if (!Number.isFinite(n)) return fallback;
    return Math.min(max, Math.max(min, n));
  };

  function safeColors(colors) {
    const out = {};
    for (const key of ['bg', 'panel', 'panel2', 'line', 'text', 'muted', 'accent', 'good', 'bad']) {
      out[key] = MBX.normalizeHex(colors && colors[key]) || MBX.DEFAULT_SETTINGS.customColors[key];
    }
    return out;
  }

  function contrastOn(hex) {
    const rgb = MBX.hexToRgb(hex);
    if (!rgb) return '#101114';
    const channel = (c) => {
      const s = c / 255;
      return s <= 0.03928 ? s / 12.92 : Math.pow((s + 0.055) / 1.055, 2.4);
    };
    const lum = 0.2126 * channel(rgb.r) + 0.7152 * channel(rgb.g) + 0.0722 * channel(rgb.b);
    return lum > 0.5 ? '#101114' : '#ffffff';
  }

  function sanitizeWallpaperUrl(url) {
    if (typeof url !== 'string') return '';
    let parsed;
    try {
      parsed = new URL(url.trim());
    } catch (err) {
      return '';
    }
    if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') return '';
    return encodeURI(parsed.href).replace(/["\\]/g, (ch) => (ch === '"' ? '%22' : '%5C'));
  }

  /* ------------------------------------------------------------------ */
  /* Styles                                                              */
  /* ------------------------------------------------------------------ */

  const PATCH_CSS = `
html { background: var(--bg) !important; }
body {
  background: var(--bg) !important;
  color: var(--text) !important;
  font-family: var(--mbx-font) !important;
  font-size: var(--mbx-text-size) !important;
}
::selection { background: color-mix(in srgb, var(--accent) 38%, transparent); color: var(--text); }
:focus-visible { outline-color: var(--accent) !important; }

/* scrollbars */
* { scrollbar-color: color-mix(in srgb, var(--line) 70%, var(--muted)) transparent; scrollbar-width: thin; }
*::-webkit-scrollbar { width: 10px; height: 10px; }
*::-webkit-scrollbar-track { background: transparent; }
*::-webkit-scrollbar-thumb {
  background: color-mix(in srgb, var(--line) 80%, var(--muted));
  border: 2px solid transparent; border-radius: 99px; background-clip: padding-box;
}
*::-webkit-scrollbar-thumb:hover { background: var(--accent); background-clip: padding-box; }

/* surfaces */
.fileToolbar, .toolbar, .left, .right { background-color: var(--panel) !important; border-color: var(--line) !important; }
.status { background-color: var(--panel) !important; border-top-color: var(--line) !important; }
.viewport { background-color: var(--bg) !important; }
.brand { border-bottom-color: var(--line) !important; }
.panel, .sidePreviewPanel .panel { border-color: var(--line) !important; }
.editorMenuPanel {
  background: var(--mbx-dialog) !important;
  border-color: var(--line) !important;
  border-radius: calc(var(--mbx-radius) + 4px) !important;
  box-shadow: 0 18px 38px var(--mbx-shadow) !important;
}
.motionPanel {
  background: color-mix(in srgb, var(--panel) 92%, transparent) !important;
  border-color: var(--line) !important;
  border-radius: var(--mbx-radius) !important;
}
.motionPad {
  background: radial-gradient(circle, var(--panel2) 0 55%, var(--mbx-input) 56% 100%) !important;
  border-color: var(--line) !important;
}
.motionKnob {
  background: radial-gradient(circle at 35% 35%,
    color-mix(in srgb, var(--accent) 45%, #ffffff),
    var(--accent) 60%,
    color-mix(in srgb, var(--accent) 62%, #000000)) !important;
}
.selectionMarquee {
  background: color-mix(in srgb, var(--accent) 22%, transparent) !important;
  border-color: var(--accent) !important;
}

/* nested wells and lists */
.documentList, .treeList, .selectionList, .groupList, #jsonPreview,
.itemTileVisual, .recoveryRow, .workshopProjectRow, .workshopTagOptions span,
#patternDialog .patternSummary {
  background: var(--mbx-input) !important;
  border-color: var(--line) !important;
}
#jsonPreview { color: var(--text) !important; }
.itemTileVisual { border-radius: calc(var(--mbx-radius) - 2px) !important; }

/* form controls */
input:not([type="range"]):not([type="checkbox"]):not([type="radio"]):not([type="color"]):not([type="file"]),
select, textarea {
  background: var(--mbx-input) !important;
  color: var(--text) !important;
  border-color: var(--line) !important;
  border-radius: var(--mbx-radius) !important;
}
input::placeholder, textarea::placeholder { color: var(--muted) !important; }
input:focus, select:focus, textarea:focus { border-color: var(--accent) !important; }
input[type="checkbox"], input[type="radio"], input[type="range"] { accent-color: var(--accent) !important; }

/* buttons */
button, .fileButton {
  background: var(--panel2) !important;
  color: var(--text) !important;
  border-color: var(--line) !important;
  border-radius: var(--mbx-radius) !important;
}
button:hover, .fileButton:hover { background: var(--mbx-hover) !important; border-color: var(--accent) !important; }
button.active, .documentTab.active, .documentTab[aria-pressed="true"],
.sidebarTabs [role="tab"][aria-selected="true"],
.catalogViewControls button[aria-pressed="true"],
.toolbar.tabbed .toolbarTabs [role="tab"][aria-selected="true"],
#patternDialog .patternSource label:has(input:checked) {
  background: var(--mbx-active) !important;
  border-color: var(--accent) !important;
  color: var(--text) !important;
}
.sidebarTabs [role="tab"] { border-radius: var(--mbx-radius) var(--mbx-radius) 0 0 !important; }
.itemInfoBtn { border-radius: 50% !important; background: transparent !important; color: var(--muted) !important; }
.itemTile .itemInfoBtn { background: color-mix(in srgb, var(--panel) 88%, transparent) !important; }
.itemInfoBtn:hover { background: var(--mbx-hover) !important; color: var(--text) !important; border-color: var(--accent) !important; }
.itemTile { background: var(--panel2) !important; border-color: var(--line) !important; border-radius: var(--mbx-radius) !important; }
.itemTile.selected { border-color: var(--accent) !important; }
/* The editor sizes tiles at a fixed 153px for an 82px preview. These dedicated
   pixel variables (written by apply()) keep a definite height even if a stale
   --mbx-thumb value without a unit is still sitting on <html>: an invalid var
   collapses every tile to padding height and clips the catalog. 71px is the
   id/name/tags block under the preview. */
.itemTile { height: var(--mbx-tile-h, 153px) !important; min-height: 0 !important; }
.itemList.thumbnails { grid-template-columns: repeat(auto-fill, minmax(var(--mbx-thumb-px, 88px), 1fr)) !important; }
.itemTileVisual { height: var(--mbx-visual-h, 82px) !important; }

/* selection rows */
.itemRow:hover, .itemRow.selected, .itemTile:hover, .itemTile.selected,
.treeRow:hover, .treeRow.selected, .selectionRow:hover, .selectionRow.primary,
.contentRow.selected { background: var(--mbx-hover) !important; }
.treeRow.primary { box-shadow: inset 3px 0 0 var(--accent) !important; }
.documentTab { background: var(--panel2) !important; border-color: var(--line) !important; color: var(--text) !important; }
.documentTab:hover { border-color: var(--accent) !important; }

/* links and help chrome */
.guideShortcut, .guideLink {
  background: color-mix(in srgb, var(--accent) 10%, var(--panel2)) !important;
  border-color: color-mix(in srgb, var(--accent) 45%, var(--line)) !important;
  color: var(--mbx-link) !important;
  border-radius: var(--mbx-radius) !important;
}
.guideShortcut:hover, .guideLink:hover {
  background: color-mix(in srgb, var(--accent) 20%, var(--panel2)) !important;
  color: var(--text) !important;
}
.guideTip { background: var(--panel2) !important; border-color: var(--line) !important; border-radius: var(--mbx-radius) !important; }
.guideTip strong { color: var(--text) !important; }
.guideTip a, .guideTipActions a { color: var(--mbx-link) !important; }
.catalogActionNote a { color: var(--mbx-link) !important; }
#courierServicesNav, #courierServicesTop {
  background: color-mix(in srgb, #f2c84b 16%, var(--panel)) !important;
  border-color: color-mix(in srgb, #f2c84b 55%, var(--line)) !important;
  color: var(--text) !important;
  animation: none !important;
  box-shadow: none !important;
}
#courierServicesNav:hover, #courierServicesTop:hover { background: color-mix(in srgb, #f2c84b 26%, var(--panel)) !important; }
.editorMenuBtn, .layoutModeBtn, .editorMenuHeading, .previewPlacementPanel summary,
.workspaceHeading #frameAllBtn, .workspacePresetActions button { color: var(--text) !important; }
.inlineHelp { background: var(--panel2) !important; border-color: var(--line) !important; border-radius: var(--mbx-radius) !important; }
.inlineHelp summary, .inlineHelpBody code { color: var(--mbx-link) !important; }
.scanSourceStatus {
  background: color-mix(in srgb, var(--accent) 9%, var(--panel)) !important;
  border-left-color: var(--accent) !important;
}

/* semantic text */
.documentTabDirty, .validationRow.warn, .lagCheck.review strong,
.lagCheck.review td:nth-child(2), .lagCheck li.review { color: var(--mbx-warn) !important; }
.validationRow.info { color: var(--mbx-info) !important; }
#deleteDocumentBtn, .recoveryDeleteBtn, .workshopProjectRow button.danger,
#patternMessage, #discordCodeMessage.bad, .validationRow.err,
.lagCheck.refuse strong, .lagCheck.refuse td:nth-child(2), .lagCheck li.refuse { color: var(--bad) !important; }
.recoveryRestoreBtn, .documentTabSelected, .lagCheck.ok strong { color: var(--good) !important; }
.workspaceFileActions #recoveryBtn {
  color: var(--good) !important;
  border-color: color-mix(in srgb, var(--good) 55%, var(--line)) !important;
}
.workspaceFileActions #workshopBtn {
  color: var(--mbx-link) !important;
  border-color: color-mix(in srgb, var(--accent) 55%, var(--line)) !important;
}
.workshopProjectRow button.danger { border-color: color-mix(in srgb, var(--bad) 55%, var(--line)) !important; }
.workshopProjectRow button.danger:hover { background: color-mix(in srgb, var(--bad) 18%, var(--panel2)) !important; }

/* tree badges */
.treeRow .treeBadge { background: color-mix(in srgb, var(--accent) 22%, var(--panel2)) !important; color: var(--text) !important; }
.treeRow .treeBadge.stick { background: color-mix(in srgb, #f2c84b 24%, var(--panel2)) !important; }
.treeRow .treeBadge.frozen { background: color-mix(in srgb, var(--bad) 24%, var(--panel2)) !important; }
.treeRow .treeBadge.group { background: color-mix(in srgb, var(--good) 22%, var(--panel2)) !important; }

/* lag check */
.lagCheck {
  background: var(--panel2) !important;
  border-color: var(--line) !important;
  border-left-color: var(--muted) !important;
  border-radius: var(--mbx-radius) !important;
}
.lagCheck.refuse {
  background: color-mix(in srgb, var(--bad) 12%, var(--panel2)) !important;
  border-color: color-mix(in srgb, var(--bad) 45%, var(--line)) !important;
  border-left-color: var(--bad) !important;
}
.lagCheck.review {
  background: color-mix(in srgb, var(--mbx-warn) 12%, var(--panel2)) !important;
  border-left-color: var(--mbx-warn) !important;
}
.lagCheck.ok { border-left-color: var(--good) !important; }
.lagCheck th, .lagCheck td { border-bottom-color: color-mix(in srgb, var(--line) 70%, transparent) !important; }

/* dialogs */
dialog, #gridDialog, #recoveryDialog, #packageDialog, #scanDialog, #patternDialog,
#arrayDialog, #discordCodeDialog, #importDialog, #workshopDialog {
  background: var(--mbx-dialog) !important;
  color: var(--text) !important;
  border-color: var(--line) !important;
  border-radius: calc(var(--mbx-radius) + 4px) !important;
  box-shadow: 0 24px 60px var(--mbx-shadow-strong) !important;
}
dialog::backdrop { background: rgba(0, 0, 0, 0.62) !important; }

/* toggles that depend on settings */
.mbx-translucent .fileToolbar, .mbx-translucent .left, .mbx-translucent .right,
.mbx-translucent .toolbar, .mbx-translucent .status {
  background-color: color-mix(in srgb, var(--panel) var(--mbx-panel-opacity), transparent) !important;
}
.mbx-blur .fileToolbar, .mbx-blur .left, .mbx-blur .right,
.mbx-blur .toolbar, .mbx-blur .status { backdrop-filter: blur(var(--mbx-blur)) saturate(1.15); }
/* A "soft glow" is one thin ring plus a short blur. The old 14px/38% version
   stayed lit on every mouse-clicked control and turned a neon accent into a
   halo around whole panels, so the hover and focus rules are split and only
   keyboard focus gets the blur. */
.mbx-glow button:hover, .mbx-glow .fileButton:hover {
  box-shadow: 0 0 0 1px color-mix(in srgb, var(--accent) 38%, transparent) !important;
}
.mbx-glow input:focus-visible, .mbx-glow select:focus-visible, .mbx-glow textarea:focus-visible {
  box-shadow: 0 0 0 1px color-mix(in srgb, var(--accent) 45%, transparent),
              0 0 7px color-mix(in srgb, var(--accent) 20%, transparent) !important;
}
.mbx-glow .itemTile.selected {
  box-shadow: inset 0 0 0 1px var(--accent),
              0 0 10px color-mix(in srgb, var(--accent) 18%, transparent) !important;
}
.mbx-reduce-motion *, .mbx-reduce-motion *::before, .mbx-reduce-motion *::after {
  animation-duration: 0s !important;
  animation-iteration-count: 1 !important;
  transition-duration: 0s !important;
  scroll-behavior: auto !important;
}

/* wallpapers */
.mbx-wall-dots body {
  background-image: radial-gradient(color-mix(in srgb, var(--line) 85%, transparent) 1.2px, transparent 1.2px) !important;
  background-size: 18px 18px !important;
  background-attachment: fixed !important;
}
.mbx-wall-grid body {
  background-image:
    linear-gradient(color-mix(in srgb, var(--line) 55%, transparent) 1px, transparent 1px),
    linear-gradient(90deg, color-mix(in srgb, var(--line) 55%, transparent) 1px, transparent 1px) !important;
  background-size: 28px 28px !important;
  background-attachment: fixed !important;
}
.mbx-wall-mesh body {
  background-image:
    radial-gradient(60% 60% at 12% 18%, color-mix(in srgb, var(--accent) 10%, transparent), transparent 70%),
    radial-gradient(55% 55% at 88% 78%, color-mix(in srgb, var(--good) 9%, transparent), transparent 70%) !important;
  background-attachment: fixed !important;
}
.mbx-wall-aurora body {
  background-image:
    radial-gradient(50% 40% at 20% 20%, color-mix(in srgb, var(--accent) 12%, transparent), transparent 70%),
    radial-gradient(45% 40% at 80% 30%, color-mix(in srgb, var(--bad) 8%, transparent), transparent 70%),
    radial-gradient(60% 50% at 50% 90%, color-mix(in srgb, var(--good) 9%, transparent), transparent 70%) !important;
  background-attachment: fixed !important;
}
.mbx-wall-custom body {
  background-image: var(--mbx-wallpaper-image, none) !important;
  background-size: cover !important;
  background-position: center !important;
  background-attachment: fixed !important;
}

/* declutter */
.mbx-hide-tip #guideTip { display: none !important; }
.mbx-hide-promo #courierServicesTop, .mbx-hide-promo #courierServicesNav { display: none !important; }
.mbx-hide-brand .brand { display: none !important; }
.mbx-hide-status .status { display: none !important; }
/* Hiding the status bar removes its 28px row in both normal and compact layout. */
.mbx-hide-status .center { grid-template-rows: auto minmax(0, 1fr) !important; }
.mbx-hide-film #filmPanel { display: none !important; }
.mbx-hide-validation .panel:has(#validationList) { display: none !important; }
.mbx-hide-json #jsonPreview { display: none !important; }
.mbx-hide-pet-note .catalogPetNote { display: none !important; }
.mbx-hide-hint-note #rootActionNote { display: none !important; }
.mbx-hide-sort-row .catalogControls { display: none !important; }
.mbx-hide-view-toggle .catalogViewControls { display: none !important; }
.mbx-hide-item-info .itemInfoBtn { display: none !important; }
.mbx-hide-scrollbars * { scrollbar-width: none !important; }
.mbx-hide-scrollbars *::-webkit-scrollbar { width: 0 !important; height: 0 !important; }
.mbx-hide-toolbar #sceneToolbar, .mbx-hide-toolbar .toolbar { display: none !important; }

/* compact spacing */
.mbx-compact button, .mbx-compact .fileButton { min-height: 28px; padding: 5px 8px; }
.mbx-compact .itemRow { padding: 4px 8px; }
.mbx-compact .toolbar { padding: 6px 8px; gap: 7px; }
.mbx-compact .actions { gap: 6px; padding: 0 8px 8px; }
.mbx-compact .panel { padding-bottom: 10px; margin-bottom: 9px; }
.mbx-compact .fieldNote { margin: -2px 0 7px; }
.mbx-compact .itemList.thumbnails { gap: 4px; padding: 6px; }
.mbx-compact .searchRow { padding: 6px 8px; }
.mbx-compact .catalogControls { padding: 0 8px 7px; }
.mbx-compact .brand { padding: 6px 8px 4px; }

/* FPS HUD */
#mbx-fps {
  position: fixed; right: 14px; bottom: 6px; z-index: 2147482990;
  padding: 4px 8px; border: 1px solid var(--line); border-radius: 6px;
  background: color-mix(in srgb, var(--panel) 88%, transparent);
  color: var(--muted); font: 11px/1.2 "Consolas", monospace;
  pointer-events: none; letter-spacing: .02em;
}
html.mbx-hide-site-banner #mbx-status-bar { display: none !important; }

/* ---- Revamp shell --------------------------------------------------- */
#mbx-revamp-bar { display: none; }
#mbx-revamp-bar .mbx-rv-brand { font: 800 13px/1 "Segoe UI", Arial, sans-serif; letter-spacing: .16em; }
#mbx-revamp-bar .mbx-rv-pill { padding: 2px 7px; border-radius: 999px; background: var(--accent); color: var(--mbx-on-accent); font: 800 9px/1.6 "Segoe UI", Arial, sans-serif; letter-spacing: .1em; }
#mbx-revamp-bar .mbx-rv-sep { width: 1px; height: 20px; background: var(--line); }
#mbx-revamp-bar .mbx-rv-tab, #mbx-revamp-bar .mbx-rv-act { border: 1px solid transparent; background: transparent; color: var(--muted); border-radius: var(--mbx-radius); padding: 6px 10px; font: 600 11px/1 "Segoe UI", Arial, sans-serif; cursor: pointer; letter-spacing: .03em; }
#mbx-revamp-bar .mbx-rv-tab:hover, #mbx-revamp-bar .mbx-rv-act:hover { background: color-mix(in srgb, var(--accent) 16%, transparent); color: var(--text); border-color: color-mix(in srgb, var(--accent) 45%, var(--line)); }
#mbx-revamp-bar .mbx-rv-tab.mbx-rv-on { background: color-mix(in srgb, var(--accent) 22%, transparent); color: var(--text); border-color: var(--accent); }
#mbx-revamp-bar .mbx-rv-spacer { flex: 1; }
#mbx-revamp-bar .mbx-rv-doc { max-width: 34vw; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; color: var(--muted); font: 600 11px/1.4 "Consolas", monospace; }
#mbx-revamp-bar .mbx-rv-ai { color: var(--text); border-color: color-mix(in srgb, var(--accent) 55%, var(--line)); }
#mbx-revamp-bar .mbx-rv-classic { color: var(--bad, #ff8d8d); }
#mbx-revamp-bar .mbx-rv-send { background: var(--accent) !important; color: var(--mbx-on-accent) !important; font-weight: 800 !important; }
html.mbx-revamp #mbx-revamp-bar { display: flex; align-items: center; gap: 8px; position: fixed; left: 0; right: 0; top: 0; height: 46px; z-index: 2147482000; padding: 0 12px; border-bottom: 1px solid var(--line); background: color-mix(in srgb, var(--panel) 94%, #000); backdrop-filter: blur(12px); color: var(--text); }
html.mbx-revamp #versionStatus { display: none !important; }
html.mbx-revamp .shell { position: fixed; inset: 46px 0 0 0; height: auto !important; grid-template-columns: 258px minmax(0, 1fr) 344px !important; grid-template-rows: minmax(0, 1fr) !important; }
html.mbx-revamp .shell > .fileToolbar { display: none !important; }
html.mbx-revamp .shell > .left { grid-column: 1; grid-row: 1; min-height: 0; }
html.mbx-revamp .shell > .center { grid-column: 2; grid-row: 1; grid-template-rows: auto minmax(0, 1fr) auto !important; min-height: 0; }
html.mbx-revamp .shell > .right { grid-column: 3; grid-row: 1; min-height: 0; }
html.mbx-revamp #viewport { min-height: 0; }
html.mbx-revamp .left .brand, html.mbx-revamp #guideTip, html.mbx-revamp .sidebarTabs { display: none !important; }
html.mbx-revamp .left .catalogPanel { flex: 1 1 auto; min-height: 0; }
html.mbx-revamp #itemList { flex: 1 1 auto; min-height: 0; grid-template-columns: repeat(auto-fill, minmax(104px, 1fr)) !important; }
html.mbx-revamp .right { padding: 10px 10px 48px !important; }
html.mbx-revamp #status { border-top: 1px solid var(--line); }
`;

  function createStyleEls() {
    if (styleEl) return;
    styleEl = document.createElement('style');
    styleEl.id = 'mbx-toolkit-style';
    customCssEl = document.createElement('style');
    customCssEl.id = 'mbx-toolkit-custom';
    const parent = document.head || document.documentElement;
    if (parent) {
      parent.appendChild(styleEl);
      parent.appendChild(customCssEl);
    }
  }

  function moveStyleEls() {
    if (!styleEl || !document.head) return;
    document.head.appendChild(styleEl);
    document.head.appendChild(customCssEl);
  }

  function buildBaseCss(colors) {
    const light = MBX.isLight(colors.bg);
    const shadow = light ? 'rgba(23, 32, 45, 0.16)' : 'rgba(0, 0, 0, 0.55)';
    const shadowStrong = light ? 'rgba(23, 32, 45, 0.24)' : 'rgba(0, 0, 0, 0.7)';
    return `html:root {
  --bg: ${colors.bg};
  --panel: ${colors.panel};
  --panel2: ${colors.panel2};
  --line: ${colors.line};
  --text: ${colors.text};
  --muted: ${colors.muted};
  --accent: ${colors.accent};
  --good: ${colors.good};
  --bad: ${colors.bad};
  --mbx-input: color-mix(in srgb, var(--bg) 58%, var(--panel2));
  --mbx-hover: color-mix(in srgb, var(--accent) 13%, var(--panel2));
  --mbx-active: color-mix(in srgb, var(--accent) 22%, var(--panel));
  --mbx-dialog: color-mix(in srgb, var(--panel) 82%, var(--bg));
  --mbx-link: color-mix(in srgb, var(--accent) 70%, var(--text));
  --mbx-warn: color-mix(in srgb, #e9a13b 74%, var(--text));
  --mbx-info: color-mix(in srgb, var(--accent) 74%, var(--text));
  --mbx-shadow: ${shadow};
  --mbx-shadow-strong: ${shadowStrong};
  --mbx-thumb-px: 88px;
  --mbx-visual-h: 82px;
  --mbx-tile-h: 153px;
}
${PATCH_CSS}`;
  }

  /* ------------------------------------------------------------------ */
  /* Applying state                                                      */
  /* ------------------------------------------------------------------ */

  function setInlineVar(name, value) {
    if (!document.documentElement) return;
    if (value === null || value === undefined || value === '') {
      document.documentElement.style.removeProperty(name);
    } else {
      document.documentElement.style.setProperty(name, value);
    }
  }

  function clearClasses() {
    const root = document.documentElement;
    if (!root) return;
    for (const cls of Object.keys(HIDE_CLASSES)) root.classList.remove(cls);
    for (const cls of WALL_CLASSES) root.classList.remove(cls);
    root.classList.remove('mbx-translucent', 'mbx-blur', 'mbx-hide-banned');
    root.removeAttribute('data-mbx-theme');
  }

  function apply() {
    const root = document.documentElement;
    if (!root || !styleEl) return;
    const s = state.settings;

    if (!s.enabled) {
      styleEl.textContent = '';
      customCssEl.textContent = '';
      clearClasses();
      ['--mbx-radius', '--mbx-text-size', '--mbx-font', '--mbx-thumb', '--mbx-thumb-px',
        '--mbx-visual-h', '--mbx-tile-h', '--mbx-panel-opacity',
        '--mbx-blur', '--mbx-on-accent', '--mbx-wallpaper-image'].forEach((p) => setInlineVar(p, null));
      restoreStreamer();
      teardownWidgets();
      return;
    }

    const theme = MBX.resolveTheme(s, state.customThemes);
    const colors = safeColors(theme.colors);
    styleEl.textContent = buildBaseCss(colors);
    customCssEl.textContent = state.customCss || '';

    const radius = clamp(s.radius, 0, 18, 6);
    const textSize = clamp(s.textSize, 11, 18, 13);
    const thumb = clamp(s.thumbSize, 64, 160, 88);
    const opacity = clamp(s.panelOpacity, 55, 100, 100);
    const blur = clamp(s.blur, 0, 24, 0);
    const font = (MBX.FONTS.find((f) => f.id === s.font) || MBX.FONTS[0]).stack;

    setInlineVar('--mbx-radius', radius + 'px');
    setInlineVar('--mbx-text-size', textSize + 'px');
    setInlineVar('--mbx-font', font);
    setInlineVar('--mbx-thumb', thumb + 'px');
    /* Explicit px values, independent of --mbx-thumb, so the catalog cannot collapse. */
    setInlineVar('--mbx-thumb-px', thumb + 'px');
    const visualHeight = Math.round(thumb * 0.93);
    setInlineVar('--mbx-visual-h', visualHeight + 'px');
    setInlineVar('--mbx-tile-h', (visualHeight + 71) + 'px');
    setInlineVar('--mbx-panel-opacity', opacity + '%');
    setInlineVar('--mbx-blur', blur + 'px');
    setInlineVar('--mbx-on-accent', contrastOn(colors.accent));
    const wallUrl = s.wallpaper === 'custom' ? sanitizeWallpaperUrl(s.wallpaperUrl) : '';
    setInlineVar('--mbx-wallpaper-image', wallUrl ? `url("${wallUrl}")` : null);

    for (const [cls, key] of Object.entries(HIDE_CLASSES)) {
      root.classList.toggle(cls, Boolean(s[key]));
    }
    root.classList.toggle('mbx-translucent', opacity < 100);
    root.classList.toggle('mbx-blur', blur > 0);
    for (const cls of WALL_CLASSES) root.classList.remove(cls);
    const activeWallpaper = s.wallpaper === 'custom' && !wallUrl ? 'none' : (s.wallpaper || 'none');
    if (activeWallpaper !== 'none') {
      root.classList.add('mbx-wall-' + activeWallpaper);
    }
    root.setAttribute('data-mbx-theme', theme.id);
    root.setAttribute('data-mbx-sig', signatureText());
    root.setAttribute('data-mbx-streamer', s.streamer ? 'on' : 'off');
    root.classList.toggle('mbx-revamp', Boolean(s.revamp));

    syncStreamer(true);
    syncStreamerUi();
    /* Rebuild widgets if they were torn down while disabled. Safe before body exists. */
    ensureWidgets();
  }

  /* ------------------------------------------------------------------ */
  /* Storage                                                             */
  /* ------------------------------------------------------------------ */

  function mergeSettings(raw) {
    const merged = Object.assign({}, MBX.DEFAULT_SETTINGS, raw || {});
    merged.customColors = Object.assign({}, MBX.DEFAULT_COLORS, (raw && raw.customColors) || {});
    for (const key of Object.keys(MBX.DEFAULT_COLORS)) {
      merged.customColors[key] = MBX.normalizeHex(merged.customColors[key]) || MBX.DEFAULT_COLORS[key];
    }
    merged.accentOverride = MBX.normalizeHex(merged.accentOverride) || '';
    return merged;
  }

  function readCache() {
    try {
      const raw = localStorage.getItem(CACHE_KEY);
      if (!raw) return null;
      const parsed = JSON.parse(raw);
      if (!parsed || typeof parsed !== 'object') return null;
      return parsed;
    } catch (err) {
      return null;
    }
  }

  function writeCache() {
    try {
      localStorage.setItem(CACHE_KEY, JSON.stringify({
        settings: state.settings,
        customThemes: state.customThemes,
        customCss: state.customCss,
      }));
    } catch (err) {
      /* storage can be full or blocked; the extension still works */
    }
  }

  function applyCache(cache) {
    if (!cache) return false;
    state.settings = mergeSettings(cache.settings);
    state.customThemes = Array.isArray(cache.customThemes) ? cache.customThemes : [];
    state.customCss = typeof cache.customCss === 'string' ? cache.customCss : '';
    return true;
  }

  function loadFromStorage() {
    let storage;
    try {
      storage = chrome.storage.sync;
    } catch (err) {
      return;
    }
    if (!storage) return;
    try {
      storage.get(STORE_KEYS, (res) => {
        if (chrome.runtime && chrome.runtime.lastError) return;
        if (!res) return;
        state.settings = mergeSettings(res.settings);
        state.customThemes = Array.isArray(res.customThemes) ? res.customThemes : [];
        state.customCss = typeof res.customCss === 'string' ? res.customCss : '';
        writeCache();
        apply();
      });
    } catch (err) {
      /* ignore */
    }
  }

  let persistTimer = 0;

  function persist() {
    /* The local cache is written immediately; the synced copy is debounced
       so dragging a slider cannot exhaust chrome.storage.sync's write quota. */
    writeCache();
    let storage;
    try {
      storage = chrome.storage.sync;
    } catch (err) {
      return;
    }
    if (!storage) return;
    window.clearTimeout(persistTimer);
    persistTimer = window.setTimeout(() => {
      try {
        storage.set({ settings: state.settings }, () => {
          if (chrome.runtime && chrome.runtime.lastError) {
            /* ignore quota errors */
          }
        });
      } catch (err) {
        /* ignore */
      }
    }, 250);
  }

  function update(patch) {
    state.settings = Object.assign({}, state.settings, patch);
    apply();
    persist();
  }

  function listenForChanges() {
    if (!chrome.storage || !chrome.storage.onChanged) return;
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== 'sync') return;
      if (changes.settings) {
        state.settings = mergeSettings(changes.settings.newValue);
      }
      if (changes.customThemes) {
        state.customThemes = Array.isArray(changes.customThemes.newValue) ? changes.customThemes.newValue : [];
      }
      if (changes.customCss) {
        state.customCss = typeof changes.customCss.newValue === 'string' ? changes.customCss.newValue : '';
      }
      apply();
      writeCache();
    });
  }

  /* ------------------------------------------------------------------ */
  /* Toolkit GUI bridge                                                  */
  /* ------------------------------------------------------------------ */

  function openOptions() {
    try {
      chrome.runtime.sendMessage({ type: 'mbx-open-options' });
    } catch (err) {
      /* ignore */
    }
  }

  function ensureWidgets() {
    if (!state.settings.enabled) return;
    ensureRevamp();
    ensureFps();
  }

  function teardownWidgets() {
    if (revampBar) revampBar.remove();
    revampBar = null;
    if (revampTimer) {
      window.clearInterval(revampTimer);
      revampTimer = 0;
    }
    if (revampInput && revampDocHandler) revampInput.removeEventListener('input', revampDocHandler);
    revampInput = null;
    revampDocHandler = null;
    if (fpsEl) fpsEl.remove();
    fpsEl = null;
    if (fpsRaf) cancelAnimationFrame(fpsRaf);
    fpsRaf = 0;
  }

  /* ------------------------------------------------------------------ */
  /* FPS HUD                                                             */
  /* ------------------------------------------------------------------ */

  function ensureFps() {
    const want = state.settings.enabled && state.settings.fps && document.querySelector('.viewport');
    if (!want) {
      if (fpsEl) fpsEl.remove();
      fpsEl = null;
      if (fpsRaf) cancelAnimationFrame(fpsRaf);
      fpsRaf = 0;
      return;
    }
    if (fpsEl) return;
    fpsEl = document.createElement('div');
    fpsEl.id = 'mbx-fps';
    fpsEl.textContent = 'FPS --';
    document.body.appendChild(fpsEl);
    fpsFrames = 0;
    fpsLast = performance.now();
    const tick = (now) => {
      fpsFrames += 1;
      if (now - fpsLast >= 500) {
        const fps = Math.round((fpsFrames * 1000) / (now - fpsLast));
        if (fpsEl) fpsEl.textContent = 'FPS ' + fps + ' · ' + (1000 / Math.max(fps, 1)).toFixed(1) + ' ms';
        fpsFrames = 0;
        fpsLast = now;
      }
      fpsRaf = requestAnimationFrame(tick);
    };
    fpsRaf = requestAnimationFrame(tick);
  }

  function latestName() {
    try {
      const list = JSON.parse(localStorage.getItem('mikeybox_recent_player_names') || '[]');
      if (!Array.isArray(list)) return '';
      const found = list.find((entry) => typeof entry === 'string' && entry.trim() && entry.trim().length <= 32);
      return found ? found.trim() : '';
    } catch (err) {
      return '';
    }
  }

  function copyToClipboard(text) {
    if (!navigator.clipboard || !navigator.clipboard.writeText) return;
    navigator.clipboard.writeText(text).catch(() => {
      /* clipboard can be blocked without a gesture */
    });
  }

  function buildDossier() {
    const read = (key) => {
      try {
        return localStorage.getItem(key) || '';
      } catch (err) {
        return '';
      }
    };
    const names = (() => {
      try {
        const list = JSON.parse(read('mikeybox_recent_player_names') || '[]');
        return Array.isArray(list) ? list.filter((entry) => typeof entry === 'string').slice(0, 8) : [];
      } catch (err) {
        return [];
      }
    })();
    const streamer = Boolean(state.settings.streamer);
    const recovery = (() => {
      try {
        return sessionStorage.getItem('mikeybox_goop_recovery_session_v1') || '';
      } catch (err) {
        return '';
      }
    })();
    return {
      toolkit: 'Mikeybox Toolkit · ' + (streamer ? MBX.maskSignature(MBX.SIGNATURE, true) : (MBX.SIGNATURE || '')),
      generatedAt: new Date().toISOString(),
      site: { host: location.hostname },
      player: {
        inGameName: streamer ? (names[0] ? MBX.STREAMER_NAME : '') : (names[0] || ''),
        recentNames: streamer ? [] : names,
        platform: read('mikeybox_platform') || 'quest',
        editorLayout: read('mikeybox_editor_layout_v1'),
        toolTab: read('mikeybox_editor_tool_tab_v1'),
        handTracking: read('mikeybox_hand_tracking_profile'),
        recoverySession: streamer ? '' : recovery,
      },
      streamerHidden: streamer || undefined,
    };
  }

  /* ------------------------------------------------------------------ */
  /* Streamer mode                                                       */
  /* ------------------------------------------------------------------ */

  /* Masks who is on screen, not what the editor is doing: the in-game name,
     the Prime recovery session and the build signature, everywhere they are
     printed - page text, AI Studio and copied dossiers.
     Item names, categories and prices stay readable on purpose. */
  const maskedNodes = new Map();
  let streamerAt = 0;

  function signatureText() {
    return state.settings.streamer ? MBX.maskSignature(MBX.SIGNATURE, true) : (MBX.SIGNATURE || '');
  }

  function streamerNames() {
    const names = [];
    try {
      const list = JSON.parse(localStorage.getItem('mikeybox_recent_player_names') || '[]');
      if (Array.isArray(list)) {
        for (const entry of list) {
          const name = typeof entry === 'string' ? entry.trim() : '';
          if (name.length < 3 || name.length > 32 || names.includes(name)) continue;
          names.push(name);
        }
      }
    } catch (err) {
      /* ignore */
    }
    /* Longest first, so "Ghost" cannot chew a hole out of "Ghostrider". */
    return names.sort((a, b) => b.length - a.length);
  }

  function streamerSecrets() {
    const secrets = [];
    try {
      const recovery = sessionStorage.getItem('mikeybox_goop_recovery_session_v1');
      if (recovery && recovery.length >= 6) secrets.push(recovery);
    } catch (err) {
      /* ignore */
    }
    return secrets.sort((a, b) => b.length - a.length);
  }

  function maskStreamerText(text, names, secrets) {
    return MBX.maskIdentityText(text, names, secrets);
  }

  /* Rewrites the player's own name inside text the page already rendered.
     Anything the page changes later is re-checked on the next pass. */
  function scanStreamer() {
    if (!state.settings.streamer || !document.body) return;
    const names = streamerNames();
    const secrets = streamerSecrets();
    if (!names.length && !secrets.length) return;
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, {
      acceptNode(node) {
        const text = node.nodeValue;
        if (!text || text.length < 3 || text === MBX.STREAMER_NAME) return NodeFilter.FILTER_REJECT;
        const parent = node.parentElement;
        if (!parent) return NodeFilter.FILTER_REJECT;
        if (/^(SCRIPT|STYLE|TEXTAREA|OPTION)$/.test(parent.tagName)) return NodeFilter.FILTER_REJECT;
        /* Catalog rows and the inspector list item names, not the player. */
        if (parent.closest('.itemTile, .itemRow, #itemList, .catalog, .itemInfo, .itemName, #mbx-ai-panel, #mbx-revamp-bar')) {
          return NodeFilter.FILTER_REJECT;
        }
        return NodeFilter.FILTER_ACCEPT;
      },
    });
    const pending = [];
    let node = walker.nextNode();
    while (node) {
      const known = maskedNodes.get(node);
      const original = known ? known.original : node.nodeValue;
      const masked = maskStreamerText(original, names, secrets);
      if (masked !== original) {
        maskedNodes.set(node, { original: original, masked: masked });
        pending.push([node, masked]);
      } else if (known && node.nodeValue !== original) {
        /* The page rewrote this text; stop tracking the old copy. */
        maskedNodes.delete(node);
      }
      node = walker.nextNode();
    }
    for (const [target, text] of pending) target.nodeValue = text;
  }

  function restoreStreamer() {
    for (const [node, entry] of maskedNodes) {
      if (node.isConnected && node.nodeValue === entry.masked) node.nodeValue = entry.original;
    }
    maskedNodes.clear();
  }

  /* The editor mutates constantly, so a forced pass only happens when the
     setting changes; otherwise a full text walk is rate-limited. */
  function syncStreamer(force) {
    if (!state.settings.streamer) {
      restoreStreamer();
      return;
    }
    const now = Date.now();
    if (!force && now - streamerAt < 700) return;
    streamerAt = now;
    scanStreamer();
  }

  function syncStreamerUi() {
    if (revampBar) revampBar.setAttribute('data-mbx-sig', signatureText());
  }

  /* ------------------------------------------------------------------ */
  /* Revamp shell                                                        */
  /* ------------------------------------------------------------------ */

  function syncRevampTabs() {
    if (!revampBar) return;
    for (const button of revampBar.querySelectorAll('[data-rv-tab]')) {
      const real = document.getElementById('sidebarTab' + button.dataset.rvTab);
      button.classList.toggle('mbx-rv-on', Boolean(real && real.getAttribute('aria-selected') === 'true'));
    }
  }

  function dropRevamp() {
    if (revampInput && revampDocHandler) revampInput.removeEventListener('input', revampDocHandler);
    revampInput = null;
    revampDocHandler = null;
    if (revampBar) revampBar.remove();
    revampBar = null;
    if (revampTimer) {
      window.clearInterval(revampTimer);
      revampTimer = 0;
    }
  }

  function ensureRevamp() {
    const want = state.settings.enabled && state.settings.revamp && Boolean(document.querySelector('.shell'));
    if (!want) {
      dropRevamp();
      return;
    }
    if (revampBar) {
      syncRevampTabs();
      return;
    }
    const bar = document.createElement('div');
    bar.id = 'mbx-revamp-bar';
    bar.setAttribute('data-mbx-sig', signatureText());
    bar.innerHTML = [
      '<span class="mbx-rv-brand">MIKEYBOX</span>',
      '<span class="mbx-rv-pill">REVAMP</span>',
      '<span class="mbx-rv-sep"></span>',
      '<button type="button" class="mbx-rv-tab" data-rv-tab="Items">Items</button>',
      '<button type="button" class="mbx-rv-tab" data-rv-tab="Workspace">Workspace</button>',
      '<button type="button" class="mbx-rv-tab" data-rv-tab="Wearer">Wearer</button>',
      '<span class="mbx-rv-spacer"></span>',
      '<span class="mbx-rv-doc" id="mbx-rv-doc">untitled</span>',
      '<button type="button" class="mbx-rv-act" data-rv-act="save">Save</button>',
      '<button type="button" class="mbx-rv-act" data-rv-act="download">Download</button>',
      '<button type="button" class="mbx-rv-act mbx-rv-send" data-rv-act="send">Send to game</button>',
      '<button type="button" class="mbx-rv-act" data-rv-act="load">Load</button>',
      '<button type="button" class="mbx-rv-act" data-rv-act="pickup">Pickup</button>',
      '<button type="button" class="mbx-rv-act mbx-rv-ai" data-rv-act="ai">AI Studio</button>',
      '<button type="button" class="mbx-rv-act mbx-rv-classic" data-rv-act="classic">Classic</button>',
    ].join('');
    bar.addEventListener('click', (event) => {
      const tab = event.target.closest('[data-rv-tab]');
      if (tab) {
        const real = document.getElementById('sidebarTab' + tab.dataset.rvTab);
        if (real) real.click();
        syncRevampTabs();
        return;
      }
      const act = event.target.closest('[data-rv-act]');
      if (!act) return;
      if (act.dataset.rvAct === 'save') {
        const save = document.getElementById('saveBtn');
        if (save) save.click();
      } else if (act.dataset.rvAct === 'download') {
        const download = document.getElementById('downloadBtn');
        if (download) download.click();
      } else if (act.dataset.rvAct === 'send') {
        const send = document.getElementById('sendToBotBtn');
        if (send) send.click();
      } else if (act.dataset.rvAct === 'load') {
        const load = document.getElementById('loadFromBotBtn');
        if (load) load.click();
      } else if (act.dataset.rvAct === 'pickup') {
        const pickup = document.getElementById('privatePickupBtn');
        if (pickup) pickup.click();
      } else if (act.dataset.rvAct === 'ai') {
        if (window.MBXAI && window.MBXAI.open) {
          window.MBXAI.open();
          if (window.MBXAI.selectView) window.MBXAI.selectView('build');
        }
      } else if (act.dataset.rvAct === 'classic') {
        update({ revamp: false });
      }
    });
    document.body.appendChild(bar);
    revampBar = bar;
    const input = document.getElementById('filenameInput');
    if (input) {
      const doc = bar.querySelector('#mbx-rv-doc');
      const syncDoc = () => {
        if (doc) doc.textContent = (input.value || 'untitled').slice(0, 48);
      };
      revampInput = input;
      revampDocHandler = syncDoc;
      input.addEventListener('input', syncDoc);
      syncDoc();
    }
    syncRevampTabs();
    revampTimer = window.setInterval(syncRevampTabs, 600);
  }

  /* ------------------------------------------------------------------ */
  /* Boot                                                                */
  /* ------------------------------------------------------------------ */

  function onReady() {
    moveStyleEls();
    apply();
    ensureWidgets();
  }

  function boot() {
    createStyleEls();
    const cached = readCache();
    if (cached) {
      applyCache(cached);
      apply();
    }
    loadFromStorage();
    listenForChanges();

    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', onReady, { once: true });
    } else {
      onReady();
    }

    window.addEventListener('keydown', (event) => {
      if (!state.settings.enabled) return;
      if (event.altKey && event.shiftKey && (event.key === 'm' || event.key === 'M')) {
        event.preventDefault();
        event.stopPropagation();
        openOptions();
      }
      if (event.altKey && event.shiftKey && (event.key === 'd' || event.key === 'D')) {
        event.preventDefault();
        event.stopPropagation();
        copyToClipboard(JSON.stringify(buildDossier(), null, 2));
      }
      if (event.altKey && event.shiftKey && (event.key === 's' || event.key === 'S')) {
        event.preventDefault();
        event.stopPropagation();
        update({ streamer: !state.settings.streamer });
      }
    }, true);

    /* The editor builds its panels after load; keep the widgets in sync. */
    let pending = 0;
    const observer = new MutationObserver(() => {
      if (pending) return;
      pending = window.setTimeout(() => {
        pending = 0;
        ensureWidgets();
        syncStreamer(false);
      }, 250);
    });
    const attach = () => {
      if (document.body) {
        observer.observe(document.body, { childList: true, subtree: true });
      } else {
        document.addEventListener('DOMContentLoaded', attach, { once: true });
      }
    };
    attach();
  }

  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (!message || message.type !== 'mbx-page-action') return undefined;
    if (message.action === 'send') {
      const button = document.getElementById('sendToBotBtn');
      if (!button) {
        sendResponse({ ok: false, error: 'Send button not found on this page.' });
        return false;
      }
      button.click();
      sendResponse({ ok: true, text: 'Send dialog opened.' });
      return false;
    }
    if (message.action === 'username') {
      const name = latestName();
      if (!name) {
        sendResponse({ ok: false, error: 'No recent in-game name stored yet.' });
        return false;
      }
      sendResponse({ ok: true, text: state.settings.streamer ? MBX.STREAMER_NAME : name });
      return false;
    }
    if (message.action === 'dossier') {
      sendResponse({ ok: true, text: JSON.stringify(buildDossier(), null, 2) });
      return false;
    }
    sendResponse({ ok: false, error: 'Unknown action.' });
    return false;
  });

  boot();
})();
